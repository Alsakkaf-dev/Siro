# Industrial Training (LI) and Internship Timeline: UTM SCSEH01 → KSA backend/AI
Researched 2026-10-05 (MYT). All URLs accessed 2026-10-05. "Pub" = publication/posting date where the source shows one.
Tags: [confirmed] = stated by the source; [estimate] = inferred from the sources; [assumption] = not verified, needs checking.

---------------------------------------------------------------------
## 1. UTM Faculty of Computing (FC) LI process

### Calendar anchor
- 2026/27 Sem I: 12 Oct 2026 – 21 Mar 2027. Sem II: 22 Mar 2027 – 3 Oct 2027 (lectures 22 Mar–4 Jul; finals 12–25 Jul; break 26 Jul–3 Oct 2027). [confirmed] https://amd.utm.my/wp-content/uploads/sites/460/2026/05/Final_Kalendar-Akademik-Sarjana-Muda.Sarjana.Kedoktoran-20262027-14.5.2026-pembetulan.pdf (pub May 2026)
- 2027/28 and 2028/29 calendars: not published yet (not found). Sem I 2027/28 likely starts around the 2nd week of Oct 2027; Sem I 2028/29 around Oct 2028. [estimate, based on the 2026/27 pattern]

### Eligibility and duration
- LI lasts at least 20 weeks. Older SE handbook prerequisite: 92 credits AND CGPA >= 2.0 (SECJ4118/SECJ4114). [confirmed for SECJH] https://comp.utm.my/wp-content/uploads/2023/01/Combine-Software.pdf ; https://comp.utm.my/wp-content/uploads/2024/01/Undergraduate-handbook-2023_2024.pdf
- SCSEH: 12 LI credits (8 HW compulsory attendance + 4 graded); graduation needs 128 credits, CPA >= 2.0 and 5 PSC. [confirmed] https://comp.utm.my/bachelor-in-software-engineering-w-honours/
- The codes SCSE4108/SCSE4114 and their SCSEH-specific prerequisite were not found in any public source. No public SCSEH guidebook PDF was found (guidebooks exist for SECVH 25-26). [not found]
- Placement is made only after the student (i) registers the LI course codes, (ii) meets the CPA and acquired-credit rules as of the preceding semester, and (iii) meets other FC requirements. [confirmed, older page] https://comp.utm.my/industrialtraining/preparation/ (now 404; text read from the search-index cache on 2026-10-05; it cites old codes SC*3114/3118, so it predates SCSEH)

### Steps and forms (FC LI Preparation page, cached)
- LI briefing (taklimat) runs in the **4th week of the semester before LI**. Attendance is compulsory and recorded in ITS. A student who misses it must send a show-cause letter to the LI Coordinator, submit **BLI-1A** to the Secretariat, and register in ITS. [confirmed, cached page]
  - For Oct 2027 LI, week 4 of Sem II 2026/27 falls around 12–18 Apr 2027. [estimate]
- **BLI-1C** "Application of Potential Company for Industrial Training" plus a one-page company profile goes to the LI Secretariat. It is required even when the company is already in ITS. [confirmed] cached page above; form: https://people.utm.my/rashidah/wp-content/uploads/sites/729/2017/03/BLI-1C-Borang-LI.pdf ; process post (pub 19 Mar 2017): https://people.utm.my/rashidah/2017/03/19/latihan-industri-proses-permohonan-surat-pengesahan-pelajar/ (JKLI takes ~3 working days to add the company to ITS)
- Apply in ITS to **only ONE company at a time**, then collect the confirmation letter (Surat Pengesahan Pelajar). Send the company the confirmation letter, CV and **BLI-2A** (Organisation Acceptance form). Follow up if there is no reply within 2 weeks. When the company returns BLI-2A, submit it to the Secretariat. If the company in BLI-2A differs from the one applied for in ITS, disciplinary action follows. If rejected, show proof and repeat. [confirmed, cached page]
- "BLI-1" and "BLI-1B" were not found for UTM FC. The BLI-1 found online belongs to UMS, a different university. [not found]
- No fixed calendar date for securing placement was found. [not found] Working rule: hold an accepted BLI-2A well before the LI semester. For overseas placements, the hard limit is the 30-working-day rule below. [estimate]

### Self-sourcing
- "The students should apply placement at external industry." An LI placement inside UTM is considered only after several companies reject the student and the Chair consents. [confirmed, cached page]
- Students use email, LinkedIn, websites, walk-in, etc. (UTM Faculty of Chemical & Energy Eng. page, same ITS system). [confirmed for that faculty] https://fkt.utm.my/li/resources/

### Overseas LI (applies to Saudi Arabia; no country-specific rule found)
- Prior approval from the **Ministry of Foreign Affairs Malaysia (Wisma Putra)** is required. Submit through the Office of the Deputy Vice-Chancellor (Student Affairs/HEP) **at least 30 WORKING DAYS before departure**. The submission needs: 3 copies of the application letter, 3 copies of the Placement Committee papers, the company's offer letter, and **Form KN (HEP) (Amendment 2010)** with the SC Chair's comments and support. It must state who funds airfare, meals, living costs and accommodation. The student arranges their own passport/visa; extra insurance is optional and self-paid. [confirmed, cached page] https://comp.utm.my/industrialtraining/preparation/
- 30 working days is about 6–7 calendar weeks with MY holidays. For an LI start around 11 Oct 2027, the HEP submission is due by about late Aug 2027, so the KSA offer letter is needed by about early Aug 2027. [estimate]
- Whether the Wisma Putra step applies the same way to a non-Malaysian (international) student going to his residence country: not stated. Confirm with the FC LI Coordinator. [assumption]
- UTM's separate "Overseas Industrial Training Program" (UGS nomination) is for local students only, CGPA >= 3.5, at top-100 QS universities. It is not relevant to him. [confirmed] https://civil.utm.my/international-industrial-training-2025/ (pub 2025)

---------------------------------------------------------------------
## 2. Saudi Arabia: programs and windows

Legal basis: a Premium Residency holder may work in private-sector establishments and change jobs, **excluding jobs limited to Saudi nationals**. [confirmed] Premium Residency Law, Art. (g): https://misa.gov.sa/app/uploads/2024/11/%D9%86%D8%B8%D8%A7%D9%85-%D8%A7%D9%84%D8%A5%D9%82%D8%A7%D9%85%D8%A9-%D8%A7%D9%84%D9%85%D9%85%D9%8A%D8%B2%D8%A9-%D9%84%D8%B9%D8%A7%D9%85-1445%D9%87%D9%80-%D8%A7%D9%86%D8%AC%D9%84%D9%8A%D8%B2%D9%8A-.pdf
- Since 12 Jun 2026, PR holders need an employer-filed Qiwa work permit (SAR 100) to work in the private sector. [confirmed by a secondary news source] https://www.visaverge.com/greencard/saudi-green-card-holders-must-obtain-qiwa-work-permit-to-maintain-premium-residency/ (pub 16 Jun 2026)
- Tamheer (HRDF) is open to Saudi nationals only. [confirmed] https://www.hrdf.org.sa/en/products-and-services/programs/individuals/training/graduate-development/ . Company roles tagged "Tamheer" are therefore Saudi-only.

| Program | Non-Saudi OK? | Length / start | Application window seen | Source |
|---|---|---|---|---|
| Lucidya technical intern/co-op (Backend, AI, etc.) | Nationality not stated; "only for graduating students… satisfy graduation requirements" [confirmed]. Many other Lucidya roles are tagged "Saudi Only" [confirmed] | Temporary, hybrid, Riyadh | Posted 6 May 2026, rolling [confirmed] | https://apply.workable.com/lucidya/j/972E263571/ |
| Tabby engineering internships (Backend Go, Data Eng, DataOps, QA) | **Saudi nationals only, Saudi passport required** [confirmed] | 6 months, paid; Fall '26 starts autumn 2026 | Summer '26 filled; Fall '26 open (as of 2026-10-05); "a winter intake follows" [confirmed] | https://tabby.sa/en-SA/engineering ; https://tabby.pinpointhq.com/en/postings/853ac796-1370-4449-b8c1-148737a32099 ; Backend Go (pub 16 Jun 2026): https://hiring.camp/job/KPa4b7 |
| Tabby Imagine (product/design challenge → 6-month internship, SAR 3,000/mo) | **Residents eligible** ("citizens and residents alike") [confirmed]. Product/design, not backend | Starts mid-Oct 2026 | Entries 16–30 Sep 2026 (annual pattern unknown) [confirmed] | https://tabby.pinpointhq.com/en/postings/ed3fd640-2960-4a4c-b078-8751fa0df872 |
| Elm Co-op Training | Nationality not explicitly stated; Elm says it targets "national talent" [estimate: likely Saudi-focused]. Must be a graduation requirement, 4–7 months, GPA >= 3.2/4, English [confirmed] | June batch & August batch (2026) | June batch applications 12–30 Apr 2026, interviews 3–19 May, results 21 May; August batch applications opened 21 Jun 2026, closed ~21 Jul [confirmed] | https://www.ewdifh.com/jobs/84918 (pub 12 Apr 2026); https://www.wdeftksa.com/sa/jobs/100129 (pub 21 Jun 2026) |
| stc COOP | **Saudi nationals at in-Kingdom universities only** [confirmed] | Riyadh | Batch-based; "you will be contacted" [confirmed] | https://careers.stc.com.sa/content/COOP/?locale=en_US |
| SDAIA Co-op | **Saudi nationality required** [confirmed] | >= 8 weeks | Sem I 1448H window: 5–12 Jul 2026 [confirmed] | https://tm.com.sa/16966 (pub 6 Jul 2026) |
| Aramco University Internship | **Saudi only** (listed under "for-saudi-applicants"; international page targets experienced hires) [confirmed via search snippet; page returned 403/500 when fetched] | — | — | https://www.aramco.com/en/careers/for-saudi-applicants/student-opportunities/university-and-vocational-college-internship-programs/university-internship-program |
| intelmatix Data Science & Applied AI Internship | Nationality not stated [confirmed] | Riyadh on-site, **starts Oct 2026** | Posted 14 Apr 2026, about 6 months ahead of start [confirmed] | https://intelmatix.bamboohr.com/careers/105 |
| Tamara Builders Internship & Co-op (Product Engineer Intern) | "All qualified individuals are encouraged to apply" (nationality not restricted in the text) [confirmed] | **January and June cohorts** (an Oct start does not match) [confirmed] | Closed when checked | https://www.founditgulf.com/job/software-engineering-internship-co-op-training-tamara-saudi-arabia-51505422 |
| Lean Technologies Data & AI Intern | Not stated; EEO text includes "citizenship" [confirmed] | Riyadh | Posted 15 May 2026; closed [confirmed] | https://jobs.generalcatalyst.com/companies/lean-technologies-2-16bbfe41-4aa4-4262-919f-f8331e016df0/jobs/78878668-data-ai-intern |
| ATHEER Connectivity SWE Intern (COOP) | Not stated; **Arabic fluency required** [confirmed] | Riyadh | Posted 16 Aug 2026, deadline 14 Nov 2026 [confirmed] | https://www.drjobpro.com/saudi-arabia/jobs/software-engineer-intern-coop-riyadh-atheer-connectivity-MSWFTKYV03N3N88 |
| Foodics | No current KSA engineering intern posting (Workable list checked 2026-10-05). Past backend/frontend interns appear on LinkedIn; 2025 "Foodics Folks" summer program was in Egypt | — | — | https://apply.workable.com/foodics/ ; https://www.foodics.com/press/foodics-folks-summer-internship-program/ |
| Salla | Summer co-op interns joined June 2026 (LinkedIn); current Workable list shows Tamheer roles (Saudi-only) and no open intern role | Summer | not found | https://apply.workable.com/salla/ |
| Mozn | No 2026 program found; latest evidence is the 2024 co-op/summer call [not found] | — | — | https://www.mozn.ai/careers |
| Microsoft/Oracle/SAP/Google in Riyadh | No Riyadh intern posting found [not found] | — | — | https://careers.microsoft.com/v2/global/en/universityinternship |

Pattern [estimate]: Saudi co-op batches open about 2–4 months before start (Elm: Apr for June, Jun–Jul for Aug; SDAIA: Jul for Sem I). Private firms post about 6 months ahead (intelmatix: Apr for Oct). Most government and large-company co-ops (stc, SDAIA, Aramco, Tamheer, Tabby engineering) are Saudi-only. Realistic non-Saudi targets are private startups and scale-ups whose postings carry no nationality tag (Lucidya technical co-op, intelmatix, Lean, Tamara, Atheer if Arabic is fluent), plus direct outreach.

---------------------------------------------------------------------
## 3. Malaysia fallback
| Company | Window / intake | Eligibility notes | Source |
|---|---|---|---|
| Grab MY Tech Internship (Petaling Jaya) | Applications **27 Apr – 30 Jun 2026** for an **Aug 2026–Jan 2027** programme, 3–6 months [confirmed] | Open to international students holding valid MY student visas [confirmed]. An Oct start plus 20 weeks runs past Jan, so overlap needs checking [estimate] | https://www.grab.careers/en/my-internships/ |
| Shopee MY | Seasonal intern labels "Summer 2026", "Fall 2026", "Spring 2027". MY Backend Intern (Summer 2026) is closed; Spring 2027 MY intern roles were listed by about Oct 2026 [confirmed for listings, exact dates not found] | Java/Python/Go, MySQL, Redis/Kafka | https://www.foundit.my/job/backend-engineer-intern-data-infrastructure-platform-summer-2026-shopee-malaysia-46472516 ; https://careers.shopee.com.my/jobs |
| PwC MY: Intern Software Developer, Assurance (FS) **"October 2026 Intake"** | Oct intake exists [confirmed from the title]; posting date not found | Python, SQL, SDLC (search summary) | https://pwc.wd3.myworkdayjobs.com/en-US/global_campus_careers/job/Kuala-Lumpur/Intern---Software-Developer--Assurance--Financial-Services---October-2026-Intake-_753487WD |
| Deloitte MY T&T Intern (Software Dev), KL/Penang | Posted 28 Sep 2026; rolling [confirmed] | "Priority… final semester internships"; **requires valid permit/status to work in Malaysia** [confirmed] | https://jobs.sea.deloitte.com/job/Kuala-Lumpur-T&T-Intern-Innovation-&-Cloud-Development-Centre-%28Software-Development%29-MY/1362351566/careers.deloitte.com |
| KPMG MY Technology Assurance Intern | Closes 25 Oct 2026 (IT audit, not SWE) [confirmed via search summary] | — | https://jobs.accaglobal.com/job/14160549/audit-technology-assurance-intern/ |
| PETRONAS Digital | Rolling postings (AI, Data Mgmt, Tech & Digital); min CGPA 3.00, university LI letter required [confirmed via search summary; portal not readable] | — | https://careers.petronas.com/internships/ ; https://builtin.com/job/internship-artificial-intelligence-petronas-digital-sdn-bhd-tower-2-petronas-twin-towers-klcc/10657929 |
| AirAsia MOVE | No 2026 SWE intern found; only a Software Tester Intern (deadline 19 Aug 2025) [not found] | — | https://my.prosple.com/graduate-employers/air-asia-malaysia/jobs-internships/software-tester-intern |
| GovTech-type (MY) | not found | — | — |
Note: a curriculum-based LI for an international student enrolled in Malaysia is generally coordinated by the university. [estimate, search summary] Some employers (Deloitte) still demand work status. [confirmed]

---------------------------------------------------------------------
## 4. Curriculum languages
- SCSE1013 Fundamental Programming Concepts: **C++** [confirmed]. Lecturer repo "SCSE1013-FCP-24251", language C++, created 14 Oct 2024: https://github.com/Dr-Khatib/SCSE1013-FCP-24251 . The predecessor SECJ1013 is explicitly C++: https://comp.utm.my/wp-content/uploads/2023/01/Combine-Software.pdf
- SCSE1224 Advanced Programming: **Java** [confirmed from course repos, no official syllabus found]. FC GitHub Classroom repo "norizam-fc-utm-scse1224-section-01-apweek03b-week3b-bank-app" (Java, 1 Apr 2026); "OLGTX303/ap-projectforys – SCSE1224 Advanced Programming" (Java, 12 Jun 2025); "NHRayan/TransitIQ… SCSE1224" (Java 21, 5 May 2026). Found via GitHub repo search on 2026-10-05. The older SE curriculum taught a separate Object Oriented Programming course in Java and Programming Technique II in C++ (Combine-Software.pdf).
- SCSE2103 Data Structures & Algorithm: **C++** [confirmed by a student project, not by a syllabus]. https://www.linkedin.com/posts/sai-vajhra-b1537831b_utm-cplusplus-dsa-activity-7427216868991713280-IanC (pub 11 Feb 2026). The predecessor DSA used C++ ADT/classes: http://ocw.utm.my/course/view.php?id=31

---------------------------------------------------------------------
## 5. KSA junior backend/AI intern skill bar (real postings)
1. Tabby Intern Backend (Go), pub 16 Jun 2026, Saudi-only: CS fundamentals; Go or another backend language; HTTP/APIs; basic distributed systems; DB interaction; Git; reading existing code. Plus: PostgreSQL, concurrency, containers, K8s/cloud, writing tests. https://hiring.camp/job/KPa4b7
2. Lucidya technical intern/co-op, pub 6 May 2026: "strong programming skills", fast learner, ML & Big Data product, works under the CTO. https://apply.workable.com/lucidya/j/972E263571/
3. ATHEER SWE Intern (COOP), pub 16 Aug 2026: Python/JS; DB, APIs and web fundamentals; build/test APIs; Arabic fluency + English. https://www.drjobpro.com/saudi-arabia/jobs/software-engineer-intern-coop-riyadh-atheer-connectivity-MSWFTKYV03N3N88
4. Tamara Product Engineer Intern/Co-op (closed): Java or Go, SQL, testing/code review, English. https://www.founditgulf.com/job/software-engineering-internship-co-op-training-tamara-saudi-arabia-51505422
5. Lean Technologies Data & AI Intern, pub 15 May 2026: Python, SQL, dbt; APIs and databases; AI/automation tools. https://jobs.generalcatalyst.com/companies/lean-technologies-2-16bbfe41-4aa4-4262-919f-f8331e016df0/jobs/78878668-data-ai-intern
6. intelmatix DS & Applied AI Intern, pub 14 Apr 2026: Python/R, Pandas/NumPy, statistics; SQL and Git preferred. https://intelmatix.bamboohr.com/careers/105
(MY comparison: Shopee backend intern asks for Java/Python/Go, MySQL, Redis/Kafka, REST, microservices, with Spring Boot preferred.)
Common bar [estimate]: one backend language at production level + SQL/PostgreSQL + REST/HTTP + Git + testing; Docker/K8s/cloud is a plus; Python for AI/data roles; English, with Arabic a plus or sometimes required. Languages seen in KSA backend postings: Go (Tabby, Tamara), Java (Tamara), Python (Atheer, Lean, intelmatix).

---------------------------------------------------------------------
## Timelines (fixed and estimated milestones)

### Scenario A: LI in Sem I 2027/28 (start ~mid-Oct 2027 [estimate])
- Oct 2026–Jan 2027: build projects/CV. Watch Tabby "winter intake" (Saudi-only), Tamara Jan cohort (does not fit an Oct start).
- Jan–Mar 2027: contact KSA startups directly. intelmatix-style postings appear about 6 months before an Oct start, so expect them around Apr 2027. [estimate]
- 22 Mar 2027: Sem II 2026/27 begins. [confirmed]
- ~12–18 Apr 2027: FC LI briefing (week 4 of Sem II). Compulsory; register in ITS. [estimate from confirmed "week 4" rule]
- Apr–Jun 2027: main application window. Elm-type co-op batches open Apr (June batch) and late Jun (Aug batch); SDAIA early Jul (Saudi-only); Grab MY late Apr–end Jun. [confirmed pattern from 2026] For each target: BLI-1C → ITS apply (one at a time) → confirmation letter → BLI-2A.
- By ~early Aug 2027: KSA offer letter and BLI-2A in hand. [estimate]
- By ~late Aug 2027: overseas application (Form KN(HEP), offer letter, funding statement) submitted to HEP for Wisma Putra approval, >= 30 working days before departure. [estimate from confirmed rule]
- 12–25 Jul 2027: Sem II finals; break until 3 Oct 2027. [confirmed]
- ~Oct 2027 – ~Mar 2028: LI, at least 20 weeks. [estimate]

### Scenario B: LI in Sem I 2028/29 (start ~Oct 2028 [estimate])
- All of the above shifts +12 months. The 2027/28 calendar is unpublished; Sem II 2027/28 likely starts ~late Mar 2028. [estimate]
- ~Apr 2028: LI briefing (week 4 of Sem II 2027/28). Apr–Jun 2028: applications. ~early Aug 2028: offer + BLI-2A. ~late Aug 2028: HEP/Wisma Putra submission. ~Oct 2028 – ~Mar 2029: LI. [estimate]

Open items to verify with the FC LI Coordinator / Secretariat (computing@utm.my, +607-5538828):
SCSEH LI prerequisites (credits/CGPA); current BLI form set (BLI-1/1A/1B/1C/2A); whether a KSA placement for a non-Malaysian student follows the Wisma Putra route; and the exact briefing date.
