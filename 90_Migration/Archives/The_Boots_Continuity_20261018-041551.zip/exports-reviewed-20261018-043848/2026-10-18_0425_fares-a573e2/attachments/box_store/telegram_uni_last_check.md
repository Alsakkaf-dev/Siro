# Last university Telegram check: 2026-10-14 08:21 MYT
Covered messages up to ~Oct 14 morning. Key items already reported:
- Haze: all classes online 12-16 Oct 2026 (PDF from Zira A, Oct 11)
- Amendment period moved to 15-23 Oct 2026; use Excel/GSheet timetable, not UTMSmart
- SCSE3143 UBI COMP Sec 05 midterm: Fri 27 Nov 2026, 8-10 PM, L50 (DK1 & DK2)
- SCSE1224 Sec 02: Mon 2-5 PM MPK2 -> Thu 2-5 PM N28a-MP2 from next week; another course Wed 11-1 BK8 -> Mon 2-4 PM N24-DK9
- SECP1513 Sec 01 (SECRH) class Oct 14 2-5 PM
- Qiskit Fall Fest Sat 24 Oct 2026; CyberX UTM committee apps deadline 19 Oct
Chats: FC Coursemates; Official Timetable UG FC; SCSEH/SECJH/SECJ FC UTM; SCSEH INTAKE SEM 1 2024/2025; UG FC UTM Official; SCSE3143 UBI COMP Sec 05; Academic Advising Students SCSEH
