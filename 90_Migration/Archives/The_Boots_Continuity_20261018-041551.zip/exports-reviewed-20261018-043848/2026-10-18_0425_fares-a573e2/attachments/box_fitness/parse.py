import re,json,sys,subprocess,os
UA="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120 Safari/537.36"
def fetch(url,path):
    if not os.path.exists(path) or os.path.getsize(path)<1000:
        r=subprocess.run(["curl","-sL","-A",UA,"-o",path,"-w","%{http_code} %{url_effective}",url],capture_output=True,text=True)
        return r.stdout
    return "cached"
def decoded(h):
    out=[]
    for m in re.finditer(r'self\.__next_f\.push\(\[1,"((?:[^"\\]|\\.)*)"\]\)',h):
        try: out.append(json.loads('"'+m.group(1)+'"'))
        except Exception: pass
    return "".join(out)
def arr(t,key,start=0):
    i=t.find('"'+key+'":',start)
    if i<0: return None,i
    j=i+len(key)+3
    v,_=json.JSONDecoder().raw_decode(t[j:])
    return v,i
def info(slug,lang):
    url=f"https://musclewiki.com/{lang+'/' if lang else ''}exercise/{slug}"
    p=f"pages/{lang or 'en'}_{slug}.html"
    st=fetch(url,p)
    h=open(p,errors='ignore').read()
    t=decoded(h)
    k=t.find('"correct_steps"')
    if k<0: return {"url":url,"status":st,"error":"no data"}
    # find exercise object region: search muscles_primary nearest before k
    s=t.rfind('"muscles_primary"',0,k)
    if s<0: s=t.find('"muscles_primary"')
    s=max(0,s-20000)
    def g(key,typ=list):
        pos=s
        while True:
            i=t.find('"'+key+'":',pos)
            if i<0 or i>k+30000: return None
            try:
                v,_=json.JSONDecoder().raw_decode(t[i+len(key)+3:])
                if isinstance(v,typ): return v
            except Exception: pass
            pos=i+1
    def names(v,f): return [x.get(f) or x.get('name') for x in (v or [])]
    steps=g("correct_steps") or []
    steps=sorted(steps,key=lambda x:x.get('order',0))
    ttl=re.search(r'<title>(.*?)</title>',h)
    d=g("difficulty",dict) or {}
    return {"url":url,"status":st,"title":ttl.group(1) if ttl else "",
      "name":(re.search(r'<h1[^>]*>(.*?)</h1>',h) or [None,""])[1] if re.search(r'<h1[^>]*>(.*?)</h1>',h) else "",
      "primary":names(g("muscles_primary"),'name_en_us'),
      "secondary":names(g("muscles_secondary"),'name_en_us'),
      "tertiary":names(g("muscles_tertiary"),'name_en_us'),
      "difficulty_en":d.get('name_en_us'),"difficulty":d.get('name'),
      "steps_en":[x.get('text_en_us') for x in steps],"steps":[x.get('text') for x in steps]}
if __name__=="__main__":
    print(json.dumps(info(sys.argv[1],sys.argv[2] if len(sys.argv)>2 else ""),ensure_ascii=False,indent=1))
