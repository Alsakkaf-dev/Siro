import json,re
from parse import info
from concurrent.futures import ThreadPoolExecutor
slugs="""dumbbell-front-rack-squat dumbbell-goblet-squat bodyweight-squat bodyweight-single-leg-squat dumbbell-front-rack-pause-squat
push-up incline-push-up bodyweight-knee-push-ups decline-push-up diamond-push-ups
dumbbell-row-unilateral dumbbell-single-arm-row dumbbell-single-arm-row-knee dumbbell-kneeling-single-arm-row dumbbell-single-arm-pendlay-row dumbbell-renegade-row
dumbbell-overhead-press dumbbell-seated-overhead-press dumbbell-arnold-press dumbbell-z-press elevated-pike-press bodyweight-pike-press
dumbbell-romanian-deadlift dumbbell-single-leg-stiff-leg-deadlift dumbbell-single-leg-single-arm-deadlift single-legged-romanian-deadlifts
bodyweight-single-leg-calf-raise dumbbell-single-leg-calf-raise calf-raises dumbbell-calf-raise
forearm-plank long-lever-forearm-plank weighted-forearm-plank plank
bulgarian-split-squat dumbbell-bulgarian-split-squat assisted-bulgarian-split-squat dumbbell-goblet-bulgarian-split-squat
dumbbell-sumo-squat dumbbell-goblet-cossack-squat bodyweight-cossack-squat
bench-dips box-dips bodyweight-box-assisted-dips
dumbbell-rear-delt-fly dumbbell-seated-rear-delt-fly dumbbell-head-on-bench-rear-delt-fly dumbbell-rear-delt-row
dumbbell-shrug dumbbell-silverback-shrug
dumbbell-hammer-curl dumbbell-zottman-curl dumbbell-incline-hammer-curl
single-leg-glute-bridge glute-bridge dumbbell-single-leg-glute-bridge bodyweight-feet-elevated-single-leg-glute-bridge bodyweight-single-leg-heels-elevated-hip-thrust
elbow-side-plank hand-side-plank side-plank-up-down dumbbell-elbow-side-plank side-plank-reach-through
standing-tibialis-raise wall-supported-dorsal-flexion seated-tibialis-raise dumbbell-seated-tibialis-raise dumbbell-standing-tibialis-raise
dumbbell-pullover dumbbell-wrist-curl dumbbell-wrist-extension crunches reverse-crunch adductor-leg-raise-side-lying dumbbell-laying-reverse-fly inverted-row dumbbell-row-bilateral""".split()
def run(s):
    a=info(s,"ar-sa")
    return s,a
res={}
with ThreadPoolExecutor(8) as ex:
    for s,a in ex.map(run,slugs): res[s]=a
for s in slugs:
    h=open(f"pages/ar-sa_{s}.html",errors='ignore').read()
    m=re.search(r'"@type":"ExerciseAction","name":"([^"]*)".*?"muscleGroup":(\[[^\]]*\]),"secondaryMuscleGroups":(\[[^\]]*\]),"difficulty":"([^"]*)"',h)
    if m: res[s]["ld"]={"name":m.group(1),"mg":json.loads(m.group(2)),"sec":json.loads(m.group(3)),"diff":m.group(4)}
json.dump(res,open("results.json","w"),ensure_ascii=False,indent=1)
for s in slugs:
    r=res[s];print(s,r.get("status"),r.get("error",""),"|",r.get("ld",{}).get("name"),"|P:",r.get("primary"),"S:",r.get("secondary"),"T:",r.get("tertiary"),"|",r.get("difficulty_en"),"| LD:",r.get("ld",{}).get("mg"),r.get("ld",{}).get("sec"),len(r.get("steps_en") or []))
