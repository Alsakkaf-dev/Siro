import json
R=json.load(open("results.json"))
plan=[
("A","1","Dumbbell squat (2 dumbbells)","dumbbell-front-rack-squat",["dumbbell-goblet-squat","bodyweight-squat"],["dumbbell-front-rack-pause-squat","bodyweight-single-leg-squat"],"No plain 'dumbbell squat' slug with dumbbells at sides exists in the sitemap; Front-Rack Squat (2 DBs at shoulders) is the closest 2-dumbbell match."),
("A","2","Push-up","push-up",["incline-push-up","bodyweight-knee-push-ups"],["decline-push-up","diamond-push-ups"],"Incline/knee push-up are easier regressions if full push-ups are not yet possible."),
("A","3","One-arm dumbbell row (supported)","dumbbell-row-unilateral",["dumbbell-single-arm-row","dumbbell-kneeling-single-arm-row","dumbbell-single-arm-row-knee"],["dumbbell-single-arm-pendlay-row","dumbbell-renegade-row"],"Unilateral row (off arm braced on bench/box = chair) chosen as main because it is supported AND MuscleWiki tags Traps (mid-back) + Lats as primary (the other single-arm variants list Lats only). Note: dumbbell-single-arm-row-knee is a seated elbow-on-knee row, not bench-supported."),
("A","4","Dumbbell overhead shoulder press","dumbbell-overhead-press",["dumbbell-seated-overhead-press"],["dumbbell-arnold-press","dumbbell-z-press","elevated-pike-press"],""),
("A","5","Dumbbell Romanian deadlift","dumbbell-romanian-deadlift",[],["single-legged-romanian-deadlifts","dumbbell-single-leg-stiff-leg-deadlift","dumbbell-single-leg-single-arm-deadlift"],""),
("A","6","Single-leg calf raise","bodyweight-single-leg-calf-raise",["calf-raises"],["dumbbell-single-leg-calf-raise"],"calf-raises (two-leg) is the regression."),
("A","7","Forearm plank","forearm-plank",[],["long-lever-forearm-plank","weighted-forearm-plank"],"Slug 'plank' is a medicine-ball plank, not used."),
("B","1","Bulgarian split squat","bulgarian-split-squat",["assisted-bulgarian-split-squat"],["dumbbell-bulgarian-split-squat","dumbbell-goblet-bulgarian-split-squat"],""),
("B","2","Dumbbell sumo / goblet sumo squat","dumbbell-sumo-squat",[],["dumbbell-goblet-cossack-squat","bodyweight-cossack-squat"],"No separate 'goblet sumo squat' page found; dumbbell-sumo-squat used."),
("B","3","Bench/chair dips","bench-dips",["bodyweight-box-assisted-dips"],["box-dips"],""),
("B","4","Dumbbell bent-over rear delt fly","dumbbell-rear-delt-fly",["dumbbell-seated-rear-delt-fly","dumbbell-head-on-bench-rear-delt-fly"],["dumbbell-rear-delt-row"],"With max 7 kg, progression is mostly reps/tempo; rear-delt row is the heavier-loading variant."),
("B","5","Dumbbell shrug","dumbbell-shrug",[],["dumbbell-silverback-shrug"],"MuscleWiki dumbbell-shrug page shows only 1 instruction step."),
("B","6","Dumbbell hammer curl","dumbbell-hammer-curl",[],["dumbbell-zottman-curl","dumbbell-incline-hammer-curl"],""),
("B","7","Single-leg glute bridge","single-leg-glute-bridge",["glute-bridge"],["dumbbell-single-leg-glute-bridge","bodyweight-single-leg-heels-elevated-hip-thrust","bodyweight-feet-elevated-single-leg-glute-bridge"],"MuscleWiki's steps for this page are listed out of logical order (the 'lie down' setup is step 4); reproduced as published."),
("B","8","Side plank","elbow-side-plank",["hand-side-plank"],["dumbbell-elbow-side-plank","side-plank-up-down","side-plank-reach-through"],""),
("B","9","Tibialis raise (wall-supported)","wall-supported-dorsal-flexion",["seated-tibialis-raise","standing-tibialis-raise"],["dumbbell-standing-tibialis-raise","dumbbell-seated-tibialis-raise"],"'Wall Supported Dorsal Flexion' is the exact wall-leaning toe raise. Note the page 'Standing Tibialis Raise' is actually a BARBELL + plate exercise despite having no equipment in its slug, so not suitable as main."),
]
def block(s,label):
    r=R[s];L=[]
    L.append(f"**{label}: {r['ld']['name']}** — <{r['url']}> (English: <https://musclewiki.com/exercise/{s}>)")
    L.append(f"- Primary: {', '.join(r['primary']) or '—'} | Secondary: {', '.join(r['secondary']) or '—'} | Tertiary: {', '.join(r['tertiary']) or '—'}")
    L.append(f"- Difficulty: {r['difficulty_en']} ({r['difficulty']})")
    L.append("- Steps (MuscleWiki, English / Arabic):")
    for i,(e,a) in enumerate(zip(r['steps_en'],r['steps']),1):
        L.append(f"  {i}. {e.strip()}  \n     {a.strip()}")
    return "\n".join(L)
def short(s):
    r=R[s];return f"{r['ld']['name']} — {r['url']} ({r['difficulty_en']})"
out=["# MuscleWiki research — home dumbbell (≤7 kg) + bodyweight plan","",
"Fetched 2026-10-17 (Asia/Kuala_Lumpur, UTC+8) via curl from musclewiki.com. All URLs below returned HTTP 200 and the muscles/steps/difficulty are parsed from the page's own embedded exercise data (cross-checked with the page's JSON-LD). Nothing invented.","",
"User: male, 23, 161 cm, 84.3 kg, ~35% BF, sedentary beginner. Equipment: 2 × ≤7 kg dumbbells, bodyweight, chair/door/table.","",
"> Note on the Arabic site: MuscleWiki's Arabic muscle labels contain translation errors — e.g. *Triceps* is shown as «عضلات ذات الرأسين» (that means biceps), *Traps* as «العضلات الفخذية» (thigh muscles), and *Traps (mid-back)* as «الفخذين (الجزء الأوسط من الظهر)». The English muscle names below are MuscleWiki's canonical `name_en_us` values.","",
"## Summary table",""
,"| # | Exercise | MuscleWiki page (ar-sa) | Primary | Secondary | Difficulty | Harder progression |","|---|---|---|---|---|---|---|"]
for w,n,name,m,alts,prog,note in plan:
    r=R[m]
    out.append(f"| {w}{n} | {name} | [{r['ld']['name']}]({r['url']}) | {', '.join(r['primary'])} | {', '.join(r['secondary']) or '—'} | {r['difficulty_en']} | "+"; ".join(f"[{R[p]['ld']['name']}]({R[p]['url']})" for p in prog)+" |")
out.append("")
for w,n,name,m,alts,prog,note in plan:
    out.append(f"## Workout {w} — {n}. {name}\n")
    if note: out.append(f"_Note: {note}_\n")
    out.append(block(m,"Main match")); out.append("")
    for a in alts: out.append(block(a,"Alternative/regression")); out.append("")
    for p in prog: out.append(block(p,"Harder progression")); out.append("")
cov=[
("Trapezius","Dumbbell Shrug (Traps, primary); Traps (mid-back) primary in Dumbbell Row Unilateral","Covered"),
("Rhomboids","MuscleWiki has NO separate 'rhomboids' muscle; nearest is 'Traps (mid-back)', tagged primary on the chosen Dumbbell Row Unilateral (other single-arm row variants list Lats only; rear-delt fly lists only Posterior Deltoid)","Covered indirectly (via Traps mid-back). Keep the unilateral variant; extras: [Dumbbell Row (Bilateral)](https://musclewiki.com/ar-sa/exercise/dumbbell-row-bilateral) (Traps mid-back + Lats primary); optional [Dumbbell Rear Delt Row](https://musclewiki.com/ar-sa/exercise/dumbbell-rear-delt-row) (Traps mid-back secondary)"),
("Latissimus dorsi","One-arm row (Lats primary)","Covered"),
("Triceps","Bench Dips (primary); push-up & overhead press (secondary)","Covered"),
("Glutes","Squat, RDL, Bulgarian, sumo, glute bridge","Covered"),
("Hamstrings","Dumbbell RDL (Hamstrings + Lateral Hamstrings primary)","Covered (only 1 exercise)"),
("Calves","Single-leg calf raise","Covered"),
("Pectoralis major","Push-up (Chest primary)","Covered"),
("Deltoids","Overhead press (anterior/lateral), rear delt fly (posterior), push-up (anterior, secondary)","Covered"),
("Biceps","Hammer curl (primary); row (secondary)","Covered"),
("Forearms","MuscleWiki lists Forearms on NONE of your 16 chosen main pages (hammer curl = Biceps only; only the unilateral row lists Forearms as tertiary)","GAP → [Dumbbell Wrist Curl](https://musclewiki.com/ar-sa/exercise/dumbbell-wrist-curl) / [Dumbbell Wrist Extension](https://musclewiki.com/ar-sa/exercise/dumbbell-wrist-extension), or swap to [Dumbbell Zottman Curl](https://musclewiki.com/ar-sa/exercise/dumbbell-zottman-curl) (Biceps + Forearms)"),
("Rectus abdominis","Forearm plank (Abdominals primary)","Covered (could add [Crunches](https://musclewiki.com/ar-sa/exercise/crunches) / [Reverse Crunch](https://musclewiki.com/ar-sa/exercise/reverse-crunch))"),
("Obliques","Side plank (Obliques primary)","Covered"),
("Adductors","MuscleWiki labels adductors 'Groin'/'Inner Thigh'. Dumbbell Sumo Squat lists Glutes + Lower back + Quads only — NOT adductors; goblet squat lists Groin only as tertiary","GAP → [Adductor Leg Raise (side-lying)](https://musclewiki.com/ar-sa/exercise/adductor-leg-raise-side-lying) (Inner Thigh primary) or [Bodyweight Cossack Squat](https://musclewiki.com/ar-sa/exercise/bodyweight-cossack-squat) / [Dumbbell Goblet Cossack Squat](https://musclewiki.com/ar-sa/exercise/dumbbell-goblet-cossack-squat) (Inner Thigh secondary)"),
("Quadriceps","Squat, Bulgarian split squat (Quads primary)","Covered"),
("Tibialis anterior","Standing Tibialis Raise (Tibialis primary)","Covered"),
]
out.append("## Muscle-group coverage check (per MuscleWiki's own muscle tags)\n")
out.append("| Group | Where MuscleWiki tags it in your list | Status / fix |\n|---|---|---|")
for g,w,s in cov: out.append(f"| {g} | {w} | {s} |")
out.append("\nOther notes: Lower back appears as secondary on squat front-rack, RDL and sumo squat. MuscleWiki tags the push-up's secondary as Anterior Deltoid + Triceps.\n")
out.append("## Reachability\n\nAll pages fetched successfully (HTTP 200) in both ar-sa form; no exercise lacked a match. Imperfect matches: 'dumbbell squat holding 2 dumbbells at sides' → Front-Rack Squat (dumbbells at shoulders); 'goblet sumo squat' → Dumbbell Sumo Squat; 'one-arm row on chair' → Dumbbell Row Unilateral (off-arm braced).\n")
open("musclewiki_plan.md","w").write("\n".join(out))
