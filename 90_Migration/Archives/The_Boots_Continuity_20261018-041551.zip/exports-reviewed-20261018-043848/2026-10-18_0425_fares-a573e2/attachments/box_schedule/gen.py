import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from matplotlib.patches import Patch
import arabic_reshaper
from bidi.algorithm import get_display
FP='/workspace/schedule/fonts/Amiri-Regular.ttf'
fm.fontManager.addfont(FP); fp=fm.FontProperties(fname=FP)
import re
A=lambda s:s
def m(h):h,mi=map(int,h.split(':'));return h*60+mi
C={'sleep':'#3b4a6b','prayer':'#2e8b57','work':'#e07b39','meal':'#d4a017','health':'#8e44ad','prep':'#5d6d7e','buf':'#cfd8dc','free':'#eeeeee','nap':'#7fb3d5'}
L={'sleep':'نوم','prayer':'صلاة + مشي المسجد','work':'رياضة / روتين العمود الفقري','meal':'وجبة','health':'استيقاظ / سجل صحي','prep':'التهيئة للنوم','buf':'هامش / مرن','free':'وقت حر غير مخصص','nap':'قيلولة'}
days=[('sunday','الأحد','راحة'),('monday','الاثنين','قوة A (45-60 د)'),('tuesday','الثلاثاء','مشي 20-30 د'),('wednesday','الأربعاء','قوة B (45-60 د)'),('thursday','الخميس','مشي 20-30 د'),('friday','الجمعة','قوة C أو A (45-60 د)'),('saturday','السبت','مشي طويل')]
for n,(en,ar,wk) in enumerate(days):
    rest=wk=='راحة'; walk=wk.startswith('مشي 20')
    wend='06:45' if walk else '07:15'
    B=[('00:00','05:00','sleep','نوم'),('05:00','05:12','health','استيقاظ + ماء 300-500 مل + سجل صحي (دقيقتان) + الوزن'),('05:12','05:30','buf','وضوء + أذكار · لا فيب 05:00-05:30'),
       ('05:31','05:57','prayer','الفجر ~5:41 + مشي المسجد (26 د) + ماء'),
       ('06:00','06:15','work','روتين العمود الفقري 10-15 د')]
    if rest: B.append(('06:15','07:15','buf','راحة (لا تمرين)'))
    else:
        B.append(('06:15',wend,'work',wk+' (أو مساء 17:15)'))
        if walk: B.append((wend,'07:15','buf','مرن'))
    B+=[('07:15','07:45','meal','الفطور + ماء + شاي (آخر شاي قبل 12:00)'),('07:45','08:00','buf','هامش انتقال'),
       ('08:00','12:44','free','وقت حر غير مخصص (الغداء تذكير مرن)'),('12:44','13:10','prayer','الظهر 12:54 + مشي (26 د) + ماء'),
       ('13:10','13:25','free',''),('13:25','13:45','nap','قيلولة 20 د'),('13:45','15:57','free','وقت حر غير مخصص'),
       ('15:57','16:23','prayer','العصر 16:07 (يقع في النافذة) + ماء'),('16:23','17:00','free',''),
       ('17:00','17:15','buf','هامش + ماء (غداء متأخر إن لزم)'),
       ('17:15','18:15','buf','بديل الرياضة المسائي / مرن'),('18:15','18:40','buf','هامش يومي'),
       ('18:45','19:11','prayer','المغرب 18:55 + مشي + ماء'),('19:15','19:50','meal','العشاء (وجبة) + ماء'),
       ('19:54','20:20','prayer','العشاء 20:04 + مشي + ماء'),('20:20','22:00','buf','مرن / تجهيز الغد · تقليل الفيب 30-60 د/يوم'),
       ('22:00','23:00','prep','التهيئة: إضاءة خافتة، لا شاشات، لا شاي/فيب، تمدد/قراءة، وضوء، أذكار'),
       ('23:00','24:00','sleep','إطفاء الأنوار 23:00 · نوم')]
    fig,ax=plt.subplots(figsize=(9,22))
    ax.axhspan(m('08:00'),m('17:00'),xmin=0,xmax=1,color='#f5f5f5',zorder=0)
    for s,e,k,t in B:
        s,e=m(s),m(e); ax.barh((s+e)/2,1,height=e-s,left=0,color=C[k],edgecolor='white',lw=.6)
        if t: ax.text(0.97,(s+e)/2,A(t),ha='right',va='center',fontproperties=fp,fontsize=9 if e-s<20 else 11,color='white' if k in('sleep','prayer','work','health','prep') else 'black')
    ax.set_ylim(1440,0); ax.set_xlim(0,1); ax.set_xticks([])
    ax.set_yticks(range(0,1441,60)); ax.set_yticklabels([f'{h:02d}:00' for h in range(25)])
    ax.set_title(A(f'{ar} — {wk}  (مواقيت الصلاة مثال JHR02 2026-10-14)'),fontproperties=fp,fontsize=15)
    ax.legend(handles=[Patch(color=C[k],label=A(L[k])) for k in C],prop=fp,loc='upper center',bbox_to_anchor=(.5,-.01),ncol=3)
    plt.tight_layout(); plt.savefig(f'/workspace/schedule/day_{n+1}_{en}.png',dpi=110); plt.close()
