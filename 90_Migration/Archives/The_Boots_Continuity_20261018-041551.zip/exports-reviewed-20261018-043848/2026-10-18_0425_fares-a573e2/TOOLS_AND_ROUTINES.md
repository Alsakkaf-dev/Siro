# TOOLS_AND_ROUTINES — الأدوات والصلاحيات والروتينات
تصدير 2026-10-18 04:25 KL. «مختبر» = اختُبر فعليًا بتاريخ ودليل. «غير متحقق» = متاح ظاهريًا فقط. وجود موصل ≠ إذن باستخدامه (00_Core\PERMISSIONS.md). **لا بيانات اعتماد في هذا الملف**؛ أي إعادة ربط تحتاج محمد نفسه.

## أ. البيئة
- جهاز محمد Windows، machineId 20d3d907-1196-443b-9425-311941f85ac3، PowerShell، مستخدم GIGIABYTE. ROOT = C:\Users\GIGIABYTE\Desktop\Storage\UTM\Grok Boot\The_Boots؛ LIBRARY = …\Grok Boot\Library.
- صندوق فارس (Linux، Debian 13 حسب جرد 2026-10-14)، مشترك بين وكلاء محمد؛ مخزن البوت: /cursor/stores/store-f2b8c603-1d5a-417d-93f4-f366389ac6ba.
- مسار مشاريع PetroSpecial: Library\Projects\Software\PetroSpecial (قراءة فقط).

## ب. القدرات المختبرة (STATE\CAPABILITIES.md rev2 + وقائع لاحقة)
| القدرة | الحالة | التاريخ | الدليل |
|---|---|---|---|
| قراءة ROOT | مختبر | 2026-10-13 20:54 | CAPABILITIES.md |
| كتابة OUTPUT وإعادة القراءة | مختبر | 2026-10-13 20:54 | OUTPUT\access-check.txt |
| قراءة PetroSpecial | مختبر (قراءة فقط) | 2026-10-13 20:56 | petro-inventory.md |
| كتابة STATE/OUTBOX + نسخ احتياطية | مختبر | 2026-10-18 03:26 / 03:40 | backup_2026-10-18، backup_2026-10-18_phase2 |
| Git | unknown | — | لا .git في PetroSpecial |
| استمرار الملفات بين الجلسات | unknown (رسميًا) | — | لم يُختبر بمحادثة جديدة |
| Telegram Web على متصفح الصندوق (قراءة) | عمل 2026-10-14؛ **الجلسة خارجة** منذ ~15 أكتوبر | 2026-10-14 7:07 | Report؛ telegram_uni_last_check.md |
| لينكدإن عبر متصفح الصندوق (قراءة) | عمل 2026-10-14 بعد دخول محمد | 2026-10-14 7:17–7:25 | PROFILE.md؛ الحالة الآن غير متحققة |
| JAKIM e-solat API | يعمل | آخر نجاح 2026-10-18 03:19 | prayer_times.json (serverTime 2026-10-18 03:19:36) |
| جلب MuscleWiki بـcurl | عمل | 2026-10-17 | /workspace/fitness/musclewiki_plan.md |

## ج. الموصلات (حسب ملخص فارس؛ حالة الاختبار غالبًا غير متحققة)
| الموصل | الحد المسموح لفارس | ملاحظات |
|---|---|---|
| Gmail | «لا يثبت الربط وحده إذن القراءة» (PERMISSIONS) | رُبط 2026-10-14 (شخصي + UTM)؛ UTM فُك 2026-10-18 2:15 بواسطة راشد |
| Outlook-calendar | **ممنوع الكتابة** | راشد الكاتب الوحيد؛ الحساب الرسمي mohammeed.alsakkaaf@outlook.com |
| Google Drive/Docs/Sheets/Slides | ضمن النطاق فقط | رُبطت 2026-10-14 على الحسابين؛ حسابات UTM فُكت 2026-10-18 2:15 (محاولة فارس RemoveMcpAccount أعادت «not found» لأنها أزيلت مسبقًا) |
| GitHub (cursor-github) | لفارس وحده: قراءة؛ تعديل فرع/نسخة عمل مأذونة؛ لا push/merge بلا تفويض | حساب Alsakkaf-dev (Report 2026-10-14) — لم يُختبر هنا |
| Cursor Origin | كـGitHub | غير متحقق |
| Telegram (plugin) | قراءة/تنزيل فقط؛ **الإرسال مقفل** | البوت (masterTelei_bot) يرسل فقط ولا يستقبل (2026-10-14). توكنات بوت لُصقت في الدردشة 2026-10-14 ونصح فارس بإلغائها — **لم تُنسخ هنا** |
| Serena، Playwright، Firebase | داخل النطاق المهني فقط، بلا تثبيت/نشر بلا إذن | غير متحقق |
| Notion plugin، Figma plugin | — | غير متحقق |
| X (قراءات عامة) | قراءة | غير متحقق |
| UTM portal/بريد UTM | **ممنوع على فارس** | — |
| لينكدإن | قراءة فقط عند طلب محمد | — |

## د. حدود ثابتة
- لا git commit/push، لا تثبيت، لا سكربتات، لا نشر على جهاز محمد بلا إذن. لا قراءة .env/مفاتيح/كلمات مرور. لا حذف/نقل في Library (باستثناء ما في DECISIONS D8/D9). لا تغيير ربط حسابات أو صلاحيات. الإرسال/النشر/الحجز/الشراء يحتاج تفويضًا محددًا. حفظ ملف في OUTBOX ليس توصيلًا.

## هـ. الروتينات (خادمية، تابعة لبوت فارس) — **نص البرومبت متحقق**
تحقق الوكيل الأب منها بقراءة routine get في 2026-10-18 04:29 KL. الروتينات تعيش مع هذا البوت **ويُرجح أن تُحذف عند حذف البوت**. النص الكامل محفوظ هنا لإعادة إنشائها **فقط بعد موافقة محمد الصريحة** (قاعدة 03:39: لا إنشاء/إيقاف/نقل روتينات؛ ملكيتها غير محسومة).

### 1) «ملخص مجموعات الجامعة اليومي»
- id: automation-1791932943804 · enabled · الجدول: `CRON_TZ=Asia/Kuala_Lumpur 17 8 * * *` (يوميًا 8:17 صباحًا KL)
- المنفّذ: فارس (هذا البوت) عبر وكيل computerUse على متصفح صندوقه.
- آخر تشغيل: 2026-10-17 8:19 «succeeded» حسب حالة الروتين — **لكن** الملخص فشل فعليًا 2026-10-15 (8:25) و2026-10-17 (8:20) لخروج جلسة Telegram Web؛ آخر أرشيف يغطي حتى ~2026-10-16 5:44 صباحًا؛ حالة 16 أكتوبر غير واضحة.
- ملاحظة: البرومبت **يفترض أن متصفح الصندوق مسجل الدخول** — وهو حاليًا خارج الجلسة. محتوى الملخص دراسي (مجال سالي) → ملكية غير محسومة.
- البرومبت حرفيًا:
```
Once a day, check Mohammed's university Telegram groups and channels on Telegram Web (web.telegram.org/k, his personal account is already signed in in the box browser) using a computerUse subagent. STRICT permanent rule: read-only. Never type, send, react, forward, delete, join or leave anything, and never open personal one-to-one chats; only university/UTM/course groups and channels. Downloading and reading files is allowed. Summarize what is new since the last daily check (announcements, deadlines, timetable changes, class changes, shared files) and send Mohammed a short Arabic summary in chat. If nothing new, say so in one line. If the session is signed out, tell him.
```
- ملف مرتبط: attachments\box_store\telegram_uni_last_check.md (آخر فحص مكتوب 2026-10-14 08:21 MYT).

### 2) «تحديث مواقيت الصلاة - سكوداي»
- id: automation-1791935787875 · enabled · الجدول: `CRON_TZ=Asia/Kuala_Lumpur 13 3 * * *` (يوميًا 3:13 صباحًا KL)
- المنفّذ: فارس. آخر تشغيل 2026-10-18 3:19 succeeded (يطابقه serverTime في الملف).
- ملاحظة: الصلاة الآن مجال راشد (D-R-012: مواقيت الصلاة من JAKIM ضمن سجل راشد) → **الملكية غير محسومة**.
- البرومبت حرفيًا:
```
Refresh the Skudai/Johor Bahru prayer times: fetch the JAKIM e-solat API for zone JHR02 (https://www.e-solat.gov.my/index.php?r=esolatApi/TakwimSolat&period=week&zone=JHR02) and save the JSON to /cursor/stores/store-f2b8c603-1d5a-417d-93f4-f366389ac6ba/prayer_times.json. Stay quiet unless the fetch fails twice; in that case, tell Mohammed briefly in Arabic.
```
- نسخة الملف الحالي: attachments\box_store\prayer_times.json (أسبوع 18–25 أكتوبر 2026؛ اليوم: الفجر 5:40، الظهر 12:53، العصر 4:08 م، المغرب 6:54 م، العشاء 8:03 م).
- ملاحظة: مخزن البوت قد يُحذف مع البوت؛ إن أُعيد إنشاء الروتين فالمسار سيختلف في البوت الجديد.

### قاعدة تاريخية مرتبطة
- 2026-10-14 7:56: «مواقيت الصلاة في كل رد» (حساب الوقت للصلاة القادمة واقتراح بناءً عليه) — [تاريخي] قبل نقل الصلاة لراشد؛ سريانها الآن غير محسوم.
