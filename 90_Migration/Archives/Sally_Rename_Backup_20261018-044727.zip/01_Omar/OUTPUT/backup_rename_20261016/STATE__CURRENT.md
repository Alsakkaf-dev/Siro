# عمر — الحالة الأكاديمية
revision: 4
recorded_at: 2026-10-13T21:55+08:00 (ساعة الجهاز)
observed_at: 2026-10-13 (مزامنة ملفات محلية من Library؛ ليست تحققًا من البوابة)
source: Library\Academic-Records + Academic-Program + Academic-Calendar-and-Timetables (المسارات نسبة إلى Library)
الوسوم: مثبت في وثيقة | محسوب | افتراض | قديم | غير معروف. «مثبت في وثيقة» = مثبت في ذلك الملف المحلي بتاريخه، لا تحقق جديد من الجامعة.

## الحقائق الأساسية
| البند | القيمة | الحالة | المصدر | تاريخ الوثيقة |
|---|---|---|---|---|
| البرنامج | SCSEH01 Bachelor in Software Engineering with Honours، UTM، Matric A23CS4026 | مثبت في وثيقة | Academic-Records\Graduation-Audit.pdf (صورة، قُرئت بصريًا) | 2026-10-04 |
| السمستر الحالي | 202620271 (2026/2027-I)؛ BIL SEMESTER 5 في الـaudit | مثبت في وثيقة | Graduation-Audit.pdf + 2026-2027-Sem-1-Course-Registration.pdf | 2026-10-04 |
| رقم السنة | القسيمة: YEAR/PROGRAMME 2 / SCSEH؛ خطاب الحالة: Current Semester 4/8 | مثبت في وثيقة، متعارض/قديم | Supporting-Letters\SEM-5-Student-Status-Letter.pdf | 2026-07-22 |
| CGPA (PNGK) | 2.55 | مثبت في وثيقة | 2025-2026\Semester-2\2025-2026-Sem-2-Exam-Results.pdf + Exam-Result-Letters\Examination-Result.pdf | 2025/26-II |
| نقاط الجودة JMN التراكمية | 155.66 | مثبت في وثيقة | نفس المصدر | 2025/26-II |
| KK (مقام المعدل) | 61 | مثبت في وثيقة | نفس المصدر | 2025/26-II |
| KD (ساعات مكتسبة) | 57 | مثبت في وثيقة | نفس المصدر | 2025/26-II |
| آخر سمستر | KD 12، KK 18، JMN 40.02، PNG 2.22، GOOD PASS | مثبت في وثيقة | نفس المصدر | 2025/26-II |
| الساعات المسجلة الآن | 12 (TOTAL CREDIT REGISTERED 012) | مثبت في وثيقة | 2026-2027\Semester-1\2026-2027-Sem-1-Course-Registration.pdf | 2026-10-04 |
| مطلوب التخرج | 128 (هيكل: CUMULATIVE 128؛ audit: T82+E18+U20+B6+K2) | مثبت في وثيقة | SCSEH-Course-Structure-Intake-2024-2025-Rev-2024-11-05.pdf + Graduation-Audit.pdf | 2024-11-05 / 2026-10-04 |
| المتبقي | 128 − 57 = 71 | محسوب | — | — |
| تاريخ التخرج المتوقع (رسمي) | 29 AUGUST 2029 | مثبت في وثيقة (خطاب حالة قديم نسبيًا) | SEM-5-Student-Status-Letter.pdf | 2026-07-22 |
| المرشد | MUHAMMAD LUQMAN BIN MOHD SHAFIE | مثبت في وثيقة | القسيمة | 2026-10-04 |
| إعادات معلقة | SCSE2233 D (G، UM/UK) و SCSP3213 D (G، UM/UK) | مثبت في وثيقة | نتائج 2025/26-II + audit | 2026-10-04 |
| إعادات منجزة | SCSR2213 D→B- (UK)، SCST1223 D→C- (UK) | مثبت في وثيقة | نفس المصادر | 2025/26-II |

## التسجيل الحالي (آخر قسيمة 2026-10-04؛ مطابقة لقسيمة 2026-09-23)
| الرمز | المادة | الساعات | الشعبة | الوقت/القاعة | حالة التسجيل | حالة الوقت |
|---|---|---|---|---|---|---|
| SCSE3103 | Cognitive Computing | 3 | 05 | الخميس 2:00–4:50 مساءً، N28a-BT2 | مثبت في وثيقة | قديم (study.md/XLSX من جدول SCSEH، الجدول الأصلي ليس في نطاق القراءة) |
| SCSE3143 | Ubiquitous Computing | 3 | 05 | الأربعاء 2:00–4:50 مساءً، CCNA | مثبت في وثيقة | قديم (نفس المصدر) |
| SCSE3203 | Special Topics | 3 | 15 | غير معروف | مثبت في وثيقة | غير معروف — عائق |
| SFMX1063 | Information Technology in Business (FC، NFE) | 3 | 02 | الجمعة 3:00–6:00 مساءً، F3-02 بلوك T08 | مثبت في وثيقة | قديم (FE.xlsx عبر study.md) |
المجموع المسجل: 12 = مثبت في وثيقة.

## غير مسجل (لا قسيمة تثبته)
- UHLB2122 (2): خطة «Add 15 Oct» — افتراض/مخطط (Academic-Program\Mohammed-SCSEH-Study-Plan-2026-10-12.pdf، خطة شخصية لا قسيمة).
- UHLB3132 (2): خطة «Add 15 Oct»؛ موافقة مرشد منقولة 10-07 — قديم، لا يثبت التسجيل.
- UHLF1112 ش13 (2) «Late reg. by 14 Oct» مرشحة؛ بدائل UHLJ1112 ش6 (الأربعاء 5–7 مساءً، D06-BK13) وUHLC1112 ش21 (الثلاثاء 5–7 مساءً، القاعة غير ظاهرة في PDF). أوقات الشعب مثبتة في Foreign-Languages-Timetable-2026-2027-Sem-1.pdf (2026-10-07)؛ التسجيل غير معروف.
- Free Elective II (3) في الخطة PDF: غير مسجل؛ مجموع 19 في الخطة ليس تسجيلًا (C20).
أُسقط من «المثبت» كل ما ليس في القسيمة؛ 18 حمل مستهدف قديم فقط.

## المعدل — سقف هذا السمستر (محسوب من أرقام قُرئت اليوم)
- المعادلة: CGPA_max = (JMN + Σ(ساعات محتسبة جديدة × 4.00)) / (KK + ساعات محتسبة جديدة).
- 12 ساعة مسجلة (مثبتة) كلها A: (155.66 + 12×4) / (61 + 12) = 203.66 / 73 = 2.7899 — محسوب. المدخلات طابقت القيم القديمة فالناتج نفسه.
- سيناريو 18 إن أُضيفت 6 ساعات بدرجة: (155.66 + 18×4) / (61 + 18) = 227.66 / 79 = 2.8818 — محسوب على افتراض، ليس تسجيلًا.
- افتراضات: SFMX1063 (NFE) تدخل KK بدرجتها؛ إعادتا SCSE2233/SCSP3213 غير مسجلتين هذا السمستر فلا استبدال لـD. KD لا يُستخدم مقامًا.

## التعارضات القائمة
- C-YEAR: القسيمة «YEAR 2» وخطاب 2026-07-22 «4/8» مقابل audit «BIL SEMESTER 5» — قديم/ترميز سنة، لا يؤثر على الحساب.
- C-GRAD: خطاب الحالة 2029-08-29 مقابل تقديرات 2029-02/03 القديمة (C03) — قديم، الرسمي متوقع وليس مضمونًا.
- C-UKQA: قائمة المنهج (SCSEH-Curriculum-Course-List.pdf) تدرج UKQA2022 (2) ضمن FACULTY CORE وجمع البنود 84 مع عنوان 82؛ الهيكل والـaudit لا يذكرانها — يحتاج مرشد.
- C07 (55/57 وفئة اللغة)، C19 (التدريب 8 HW + 4 بدرجة؛ الهيكل يصف SCSE4108 بـHW) — قائمة.
- C05 مواعيد اللغة/الإضافة: لا وثيقة رسمية في النطاق تثبت 14 أو 15–23 أكتوبر؛ التقويم الأكاديمي لا يذكر add/drop — قديم/غير معروف.
- تقويم PDF الملايوي يكتب «7 Disember 2026 - 24 Januari 2026» والإنجليزي 2027 — خطأ طباعي، المعتمد 2027-01-24.

## بيانات ناقصة
وقت/قاعة SCSE3203 ش15؛ دليل تسجيل اللغة وUHLB؛ وقت إغلاق 10-14؛ course outlines؛ احتساب اللغة (B أم غيرها)؛ PSC؛ PSM/التدريب.
## تأكيد e-learning (دليل من البوابة عبر محمد، لم يختبره البوت) — 2026-10-13
لقطات elearning.utm.my «My courses» أرسلها محمد اليوم تُظهر 4 مواد فقط، مطابقة للقسيمة:
| الرمز-الشعبة | الاسم بالإنجليزية | ما في الصفحة |
|---|---|---|
| SCSE3103-05 | Cognitive Computing | Course Information (CI) PDF؛ المنسقة Dr Norsham binti Idris (norsham)، ومحاضرة ثانية Dr. Sim Hiew Moi (hiewmoi)؛ الأسبوع 1 أونلاين متزامن |
| SCSE3143-05 | Ubiquitous Computing | إعلان: «Class on 14 October 2026 - 2.00pm will be conducted ONLINE. Link will be provided in Telegram Group»؛ Topic 1 Introduction PDF؛ أقسام أسبوعية حتى 11–17 Jan؛ CI: Dr Muhammad Khatibsyarbini Abd Rahim (N28-402-09، khatibsyarbini@utm.my) + Prof Dr. Dayang Norhayati Abang Jawawi (N28-305-03، dayang@utm.my) |
| SCSE3203-15 | Special Topics | فارغة (Announcements + New section) — الوقت والقاعة لا يزالان غير معروفين |
| SFMX1063-02 | Information Technology in Business | فارغة |
الحالة: تسجيل المواد الأربع = مثبت في وثيقة (القسيمة) + دليل بوابة من المستخدم. لا أثر لـUHLB2122 أو UHLB3132 أو أي لغة في e-learning حتى 2026-10-13 (ليس دليل عدم تسجيل؛ قد تتأخر المزامنة) — غير معروف.
ملف رابع مرفق (UNIDENTIFIED_password-protected_750355.pdf): **ignored** بتوجيه محمد 2026-10-13 22:28؛ ليس ملفًا أكاديميًا؛ النسخة باقية في OUTPUT ولا تُستخدم.
## ملفات المواد (Library\Bachelor in Software Engineering\Year 3\SEM 5) — 2026-10-13 22:3x
CC SCSE3103-05 (Cognitive Computing)، UC SCSE3143-05 (Ubiquitous Computing)، ST SCSE3203-15 (Special Topics)، ITB SFMX1063-02 (Information Technology in Business)؛ لكل مجلد 01-Course-Information … 08-Recordings. السجل: OUTPUT\file-moves_2026-10-13.csv.