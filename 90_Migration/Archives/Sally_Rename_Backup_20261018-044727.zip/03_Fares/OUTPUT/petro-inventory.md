# جرد PetroSpecial — جرد قراءة محلي
observed_at: 2026-10-13T20:56+08:00
المسار: C:\Users\GIGIABYTE\Desktop\Storage\UTM\Grok Boot\Library\Projects\Software\PetroSpecial
الطريقة: سرد أسماء الملفات فقط (عمق 1–2، وبحث عن .git حتى عمق 4). لم يُقرأ كود ولا .env، ولم يُشغَّل شيء. التقنية مستنتجة من الأسماء فقط [افتراض].
عدد المجلدات المباشرة: 10. مقارنة بقائمة 2026-10-13 السابقة: لا اختفاء ولا ظهور.
Git: لم يوجد أي مجلد .git في أي مسار حتى عمق 4 → لا فرع ولا commit. ملفات .idea/vcs.xml و.github/workflows توحي بأصل Git سابق [افتراض].
node_modules: غير موجود في أي مجلد → لا تثبيت تبعيات ظاهر.

| # | المجلد | README | manifest | التقنية الظاهرة | .git | التقدير | ما لا يمكن الجزم به |
|---|---|---|---|---|---|---|---|
| 1 | Arabic-Flutter-Workspace | نعم + أدلة md متعددة | pubspec_arabic.yaml (ليس pubspec.yaml)؛ flutter/pubspec.yaml للـSDK | Flutter/Dart: ملفات dart مفردة + نسخة Flutter SDK كاملة داخل flutter\ | لا | وثائق ومقتطفات/نسخة SDK، ليس تطبيقًا كامل البنية | هل يوجد تطبيق فعلي؛ وجود backend حسب BACKEND_API_SPEC |
| 2 | Archive-Packages | لا | لا | PetroSpecial-Website-Main.zip (1.37MB، 2026-01-19) | لا | أرشيف | محتوى الأرشيف ومطابقته لـWebsite-Main (لم يُفك) |
| 3 | ERP-and-Website | erp-system\README.md | erp-system\package.json + package-lock | Next.js + TypeScript (next.config.ts، app، components) | لا (.idea\vcs.xml فقط) | المرشح الوحيد باسم ERP؛ قابل للتشغيل بعد npm install [افتراض] | هل فيه منطق ERP فعلي أم قالب create-next-app؛ قاعدة بيانات |
| 4 | Initial-Website | لا | لا | index.html + نسخة wp-content (لقطة WordPress محفوظة) | لا | أرشيف/لقطة موقع قديم | مصدر اللقطة وتاريخها |
| 5 | NextJS-Prototype | لا | package.json + lock | Next.js + Tailwind + TS، مكونات 3d | لا | نموذج أولي للواجهة | الغرض ومن يستخدمه |
| 6 | Website | لا | لا | HTML ثابت (about/index/offerings) | لا | نسخة جزئية/مكررة من موقع ثابت | علاقتها بـWebsite-Main |
| 7 | Website-Clone | لا | لا | HTML/CSS/JS ثابت + GitHub Pages (jekyll-gh-pages.yml) + CNAME=petrospecial.com | لا | نسخة مكررة قريبة من Website-Main | أيهما المنشور فعلًا |
| 8 | Website-from-Omar | لا | لا | zip (6.26MB، 2025-12-01) + مستخرج: petrospecial.com/index.html وقالب startbootstrap-agency | لا | أرشيف/مكرر («Omar» اسم شخص/مصدر، ليس بوت عمر) | محتوى الأرشيف كاملًا |
| 9 | Website-Main | لا | لا | HTML/CSS/JS ثابت + jekyll-gh-pages.yml | لا | موقع ثابت، مرشح لموقع الشركة التعريفي [افتراض] | هل هو المنشور حاليًا (لا CNAME فيه) |
| 10 | Website-WW | لا | petro-special\package.json + lock | HTML ثابت + مشروع Next.js جزئي (app، public، postcss) | لا | نسخة تجريبية مختلطة | الغرض |

لم تُختر نسخة مرجعية. F-001 open، F-005 blocked.