# FILES_AND_ATTACHMENTS — الملفات والمرفقات
تصدير 2026-10-18 04:25 KL. P = 03_Fares على جهاز محمد (C:\Users\GIGIABYTE\Desktop\Storage\UTM\Grok Boot\The_Boots\03_Fares). كل ملفات 03_Fares **باقية في مكانها** ولم تُعدّل؛ هذا التصدير لا ينسخها (هي على نفس الجهاز) إلا إذا ذُكر.

## أ. ملفات فارس على جهاز محمد (المرجع الأساسي)
| الملف | الحجم (بايت) | آخر تعديل | المحتوى | الدور الآن |
|---|---|---|---|---|
| P\SYSTEM_PROMPT.md | 5960 | 10-18 03:41 | التعليمات (الفريق، المجال، الملكية، القواعد، أول رد) | تعليمات حالية (معدّلة phase2) |
| P\PERSONA.md | 2851 | 10-13 18:55 | الشخصية والصورة | حالي، لم يُعدّل |
| P\WORKFLOWS.md | 7683 | 10-18 03:41 | 7 مسارات عمل (الأهداف، المهارات، الهندسة، PetroSpecial، التدريب/CV، الأنظمة، الحياة) | حالي؛ قسم 7 موسوم بأن ملكيته غير محسومة |
| P\AVATAR_PROMPT.txt، avatar.png (2.45MB)، LAUNCH_MESSAGE.txt | — | 10-13 | الصورة ورسالة الإطلاق | مرجع |
| P\STATE\RULES.md | 5868 | 10-18 03:49 | القواعد الدائمة بتواريخها | **مرجع أساسي** |
| P\STATE\SCOPE.md | 3077 | 10-18 03:41 | الاختصاصات (2026-10-14 مُستبدل + 03:24 + 03:39) | مرجع |
| P\STATE\OPEN_LOOPS.md | 2753 | 10-18 03:49 | F-001…F-006 وحالة التسليمات | **مرجع أساسي** |
| P\STATE\CURRENT.md | 1546 | 10-18 03:41 | الحالة المهنية (مثبت/قديم) | مرجع |
| P\STATE\PROJECTS.md | 616 | 10-13 | F-P001 PetroSpecial discovery | مرجع |
| P\STATE\SKILLS.md | 825 | 10-13 | مهارات غير مقاسة | مرجع |
| P\STATE\CAPABILITIES.md | 1299 | 10-13 | القدرات المختبرة | مرجع |
| P\STATE\DECISIONS.md | 308 | 10-13 | فارغ | — |
| P\STATE\CHANGELOG.md | 5323 | 10-14 12:11 | سجل 10-13/10-14 (لا يغطي 10-15→10-18) | تاريخ |
| P\STATE\PROFILE.md | 2167 | 10-18 03:41 | لينكدإن + أسطر الوزن موسومة «منقول لراشد» | مرجع مهني |
| P\STATE\TELEGRAM_RULES.md | 495 | 10-14 | قاعدة القراءة فقط | حالي |
| P\STATE\GOALS، TIME_MANAGEMENT، NUTRITION_PLAN، MEAL_WEEK_TEMPLATE، SLEEP_SYSTEM، WORKOUT_PLAN، SMOKING_CESSATION_PLAN، PRAYERS | 698–22032 | 10-18 03:26/03:49 | خطط الصحة | **نسخ سابقة** بانتظار التسليم لراشد |
| P\OUTBOX\F-003-time-limit-request.md | 681 | 10-13 | F-HO-20261013-01 | مفتوح |
| P\OUTBOX\handoff_rashed_2026-10-18.md | 5639 | 10-18 03:49 | 13 بندًا + رأس حالة | مستلم/مراجع |
| P\OUTBOX\handoff_sally_2026-10-18.md | 1384 | 10-18 03:49 | 4 بنود + رأس حالة | مستلم/مراجع |
| P\OUTPUT\petro-inventory.md | 3533 | 10-13 | جرد PetroSpecial | مرجع F-001 |
| P\OUTPUT\Fares_Full_Report.pdf | 591572 | 10-18 00:24 | تقرير فارس 14 صفحة | تاريخ (md5 مطابق لنسخة الصندوق) |
| P\OUTPUT\schedule\day_1…7.png | ~131–134KB | 10-14 12:14 | صور الأيام | تاريخ (md5 مطابقة لنسخ الصندوق) |
| P\OUTPUT\backup_2026-10-18\ (13 ملف + update_2026-10-18.ps1) | — | 10-18 03:26 | نسخ ما قبل phase1 | تاريخ — لا يُشغَّل السكربت |
| P\OUTPUT\backup_2026-10-18_phase2\ (11 ملف + update_phase2.ps1) | — | 10-18 03:40 | نسخ ما قبل phase2 (منها SYSTEM_PROMPT الأصلي 4880 بايت) | تاريخ — لا يُشغَّل السكربت |
| P\REFERENCES\growth.md | 6136 | 10-05 | مهارات وسوق سعودي وخطة جاهزية | تاريخ (مطابق md5 لـ/workspace/growth.md) |
| P\REFERENCES\decisions.md | 17237 | 10-05 | قرارات النظام القديم (7 وكلاء) وخطط السمسترات | تاريخ؛ الأكاديمي منه يخص سالي |

## ب. ملفات مشتركة قُرئت (قراءة فقط، لم تُنسخ)
00_Core\PERMISSIONS.md (rev3، 03:49)، RECORDS_AND_HANDOFFS.md (rev2)، CONFLICTS.md (rev2)، ARCHITECTURE.md (rev2)؛ 02_Rashed\STATE\ACKS.md، RECONCILE_2026-10-18.md (rev4)، DECISIONS.md (rev11)؛ 01_Omar\STATE\ACKS.md، 01_Omar\OUTBOX\REQ-20261018-SAL-001_reply-fares-handoff.md؛ Mohammed-Path-2030\README.md وstages.json.
لم تُقرأ: 00_Core\CONSTITUTION.md، PROFILE.md، SETUP.md، START_HERE.md، QA_REPORT.md لمسار 2030 — يُنصح البوت البديل بقراءتها.

## ج. المرفقات المنسوخة إلى attachments\ (من الصندوق؛ غير موجودة على الجهاز)
| المسار في التصدير | المصدر على الصندوق | الحجم | المحتوى |
|---|---|---|---|
| attachments\box_report\Fares_Full_Report.md | /workspace/report/ | 36471 | نص التقرير الكامل (مصدر الخط الزمني التفصيلي) |
| attachments\box_workspace\skudai_food_list.md | /workspace/ | 8048 | أسعار أكل سكوداي (2026-10-14) |
| attachments\box_workspace\meal_week.md | /workspace/ | 15074 | مسودة أسبوع وجبات |
| attachments\box_workspace\internship_timeline_2026-10-05.md | /workspace/ | 19590 | بحث التدريب الصناعي UTM→السعودية (2026-10-05)؛ **منشئه غير مؤكد** (النظام القديم على الأرجح) |
| attachments\box_fares\* (10 ملفات) | /workspace/fares/ | 89129 إجمالًا | نسخ عمل 2026-10-17 لـCHANGELOG/NUTRITION/MEAL/WORKOUT و.orig وed.py (سكربت تحرير)؛ NUTRITION_PLAN هنا (8658) **يختلف** عن نسخة الجهاز |
| attachments\box_fitness\musclewiki_plan.md + gen.py/batch.py/parse.py | /workspace/fitness/ | 80045 + سكربتات | خطة تمارين من MuscleWiki (2026-10-17) |
| attachments\box_schedule\gen.py | /workspace/schedule/ | 4189 | مولّد صور الجدول |
| attachments\box_store\prayer_times.json | مخزن البوت | 1846 | مواقيت JHR02 أسبوع 18–25 أكتوبر |
| attachments\box_store\telegram_uni_last_check.md | مخزن البوت | 785 | آخر فحص مكتوب لمجموعات الجامعة (2026-10-14) |

## د. ما لم يُنسخ ولماذا
- صور schedule وFares_Full_Report.pdf: موجودة على الجهاز بنفس md5 — لا حاجة.
- /workspace/fitness/pages/*.html (~78 صفحة، ~28MB)، sm.xml (5.6MB)، urls.txt (2.4MB)، en.html، push.html، slugs.txt، results.json (106KB): بيانات ويب خام قابلة لإعادة الجلب.
- /workspace/schedule/fonts/Amiri-Regular.ttf: خط عام.
- /workspace/growth.md: مطابق لـREFERENCES\growth.md.
- ملفات أخرى في /workspace (Pray.xlsx، Pray2.xlsx، finance.md، cal*، jakim*.json …): الصندوق مشترك بين البوتات وملكيتها غير مؤكدة أو تخص راشد/سالي — لم تُنسخ. Pray.xlsx (نسخة Drive UTM) مرجع C22 عند راشد.
- Library: لم يُنسخ أي شيء (بحسب التعليمات).
- سجل المحادثة الخام وتفريغ المكالمات (495 رسالة + 25 مكالمة حسب التقرير): **غير متاح** لجلسة التصدير.
- مخزن الذاكرة الدائمة (~85 حقيقة): لم يُقرأ مباشرة (لا أداة RecallMemory).
