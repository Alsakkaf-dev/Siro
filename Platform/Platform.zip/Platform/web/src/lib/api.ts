import type { AcademicNote, Assessment, Course, SearchHit, Semester, SemesterBundle, SemesterSummary } from '../../../shared/types.js';

export class ApiError extends Error {
  constructor(public status: number, message: string, public fields: Record<string, string> = {}) {
    super(message);
  }
}

// طلبات GET المتطابقة والمتزامنة تُدمج في طلب واحد؛ أي تعديل (POST/PATCH/DELETE) يفرّغ القائمة كي لا نُرجع بيانات قديمة.
const inflight = new Map<string, Promise<unknown>>();

function req<T>(method: string, url: string, body?: unknown): Promise<T> {
  if (method !== 'GET') {
    inflight.clear();
    return doReq<T>(method, url, body);
  }
  const hit = inflight.get(url);
  if (hit) return hit as Promise<T>;
  const p = doReq<T>(method, url, body).finally(() => {
    if (inflight.get(url) === p) inflight.delete(url);
  });
  inflight.set(url, p);
  return p;
}

// index.html يبدأ طلبَي /api/semesters و /api/semesters/:id مبكرًا (بالتوازي مع تنزيل الحزمة) ويضعهما في window.__pre؛ نستهلك كلًّا منهما مرة واحدة.
interface Pre { ok: boolean; status: number; text: string }
declare global {
  interface Window { __pre?: Record<string, Promise<Pre> | undefined> }
}
async function fetchRaw(method: string, url: string, body?: unknown): Promise<Pre> {
  if (method === 'GET' && window.__pre?.[url]) {
    const p = window.__pre[url];
    delete window.__pre[url];
    try {
      const r = await p;
      if (r) return r;
    } catch {
      /* نعيد الطلب عاديًّا */
    }
  }
  const res = await fetch(url, {
    method,
    headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  return { ok: res.ok, status: res.status, text: await res.text() };
}

async function doReq<T>(method: string, url: string, body?: unknown): Promise<T> {
  const res = await fetchRaw(method, url, body);
  const text = res.text;
  let data: unknown = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    /* ليس JSON */
  }
  if (!res.ok) {
    const d = (data ?? {}) as { error?: string; fields?: Record<string, string>; errors?: string[] };
    throw new ApiError(res.status, d.error ?? d.errors?.join('\n') ?? `خطأ ${res.status}`, d.fields ?? {});
  }
  return data as T;
}

export interface BackupInfo { name: string; date: string; file: string; size: number; mtime: string }
export interface Info { version: string; driver: string; schema: number; db_file: string; db_size: number; port: number; host: string }
export interface FieldChange { field: string; from: unknown; to: unknown }
export interface EntityDiff { added: { id: string; label: string }[]; removed: { id: string; label: string }[]; changed: { id: string; label: string; fields: FieldChange[] }[]; unchanged: number }
export interface DiffResult { semesters: EntityDiff; courses: EntityDiff; assessments: EntityDiff; notes: EntityDiff; totals: { added: number; removed: number; changed: number; unchanged: number } }
export interface Deleted { ok: boolean; undo: string }

export const api = {
  semesters: () => req<SemesterSummary[]>('GET', '/api/semesters'),
  bundle: (id: string) => req<SemesterBundle>('GET', `/api/semesters/${id}`),
  addSemester: (b: unknown) => req<SemesterBundle>('POST', '/api/semesters', b),
  editSemester: (id: string, b: unknown) => req<SemesterBundle>('PATCH', `/api/semesters/${id}`, b),
  activate: (id: string) => req<{ ok: boolean }>('POST', `/api/semesters/${id}/activate`),
  delSemester: (id: string) => req<Deleted>('DELETE', `/api/semesters/${id}`),
  addCourse: (semId: string, b: unknown) => req<Course>('POST', `/api/semesters/${semId}/courses`, b),
  editCourse: (id: string, b: unknown) => req<Course>('PATCH', `/api/courses/${id}`, b),
  delCourse: (id: string) => req<Deleted>('DELETE', `/api/courses/${id}`),
  addAssessment: (courseId: string, b: unknown) => req<Assessment>('POST', `/api/courses/${courseId}/assessments`, b),
  editAssessment: (id: string, b: unknown) => req<Assessment>('PATCH', `/api/assessments/${id}`, b),
  delAssessment: (id: string) => req<Deleted>('DELETE', `/api/assessments/${id}`),
  addNote: (semId: string, b: unknown) => req<AcademicNote>('POST', `/api/semesters/${semId}/notes`, b),
  editNote: (id: string, b: unknown) => req<AcademicNote>('PATCH', `/api/notes/${id}`, b),
  delNote: (id: string) => req<Deleted>('DELETE', `/api/notes/${id}`),
  undo: (token: string) => req<{ ok: boolean; label: string }>('POST', `/api/undo/${token}`),
  search: (q: string) => req<SearchHit[]>('GET', `/api/search?q=${encodeURIComponent(q)}`),
  importPreview: (file: unknown) => req<{ ok: true; diff: DiffResult }>('POST', '/api/import/preview', file),
  importApply: (file: unknown, mode: 'merge' | 'replace') => req<{ ok: true; backup: string; diff: DiffResult }>('POST', '/api/import/apply', { file, mode }),
  backups: () => req<BackupInfo[]>('GET', '/api/backups'),
  backupNow: () => req<BackupInfo>('POST', '/api/backups'),
  restore: (name: string) => req<{ ok: boolean; safety_backup: string }>('POST', '/api/backups/restore', { name }),
  info: () => req<Info>('GET', '/api/info'),
};

export type { Semester };
