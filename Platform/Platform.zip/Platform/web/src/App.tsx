import { lazy } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { Shell } from './shell/Shell.js';
import { SemesterLayout } from './core/sem-context.js';
import { useApp } from './core/app-context.js';
import Dashboard from './pages/Dashboard.js'; // الصفحة الأكثر زيارة: ضمن الحزمة الرئيسية لتقليل جولات الشبكة

const Home = lazy(() => import('./pages/Home.js'));
const Semesters = lazy(() => import('./pages/Semesters.js'));
const Courses = lazy(() => import('./pages/Courses.js'));
const CoursePage = lazy(() => import('./pages/CoursePage.js'));
const Timeline = lazy(() => import('./pages/Timeline.js'));
const Calculator = lazy(() => import('./pages/Calculator.js'));
const Weights = lazy(() => import('./pages/Weights.js'));
const Unknowns = lazy(() => import('./pages/Unknowns.js'));
const PrintSummary = lazy(() => import('./pages/PrintSummary.js'));
const Settings = lazy(() => import('./pages/Settings.js'));
const SearchPage = lazy(() => import('./pages/SearchPage.js'));
const Soon = lazy(() => import('./pages/Soon.js'));
const NotFound = lazy(() => import('./pages/NotFound.js'));

function AcademicIndex() {
  return <Semesters />;
}

export function App() {
  const { activeId } = useApp();
  void activeId;
  return (
    <Routes>
      <Route element={<Shell />}>
        <Route index element={<Home />} />
        <Route path="academic" element={<AcademicIndex />} />
        <Route path="academic/s/:semId" element={<SemesterLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="courses" element={<Courses />} />
          <Route path="courses/:courseId" element={<CoursePage />} />
          <Route path="timeline" element={<Timeline />} />
          <Route path="calculator" element={<Calculator />} />
          <Route path="weights" element={<Weights />} />
          <Route path="unknowns" element={<Unknowns />} />
          <Route path="print" element={<PrintSummary />} />
        </Route>
        <Route path="library" element={<Soon which="library" />} />
        <Route path="life" element={<Soon which="life" />} />
        <Route path="settings" element={<Settings />} />
        <Route path="search" element={<SearchPage />} />
        <Route path="home" element={<Navigate to="/" replace />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
