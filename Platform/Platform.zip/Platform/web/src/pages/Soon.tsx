import { PageHead } from '../ui/page.js';
import { Badge, Button, Card, CardHead, EmptyState, Skeleton } from '../ui/ui.js';
import { Icon, type IconName } from '../lib/icons.js';
import { StatTile } from '../widgets/tiles.js';
import { VSteps } from '../widgets/tiles.js';

const TYPES: { label: string; icon: IconName }[] = [
  { label: 'الكل', icon: 'folder' },
  { label: 'مستندات', icon: 'file' },
  { label: 'شرائح', icon: 'slides' },
  { label: 'فيديو', icon: 'video' },
];

export default function Soon({ which }: { which: 'library' | 'life' }) {
  if (which === 'life') {
    const mods: { t: string; i: IconName; d: string }[] = [
      { t: 'الروتين والعادات', i: 'check', d: 'عادات يومية وسلاسل التزام' },
      { t: 'الصلاة', i: 'clock', d: 'مواقيت وتتبّع بسيط' },
      { t: 'المال', i: 'database', d: 'مصروفات وميزانية — مشفّرة ومعزولة' },
      { t: 'الرياضة', i: 'zap', d: 'تمارين ومتابعة التقدّم' },
    ];
    return (
      <div className="page">
        <PageHead title="الحياة" icon="heart" badge={<Badge dashed>قريبًا</Badge>} sub="منصة الحياة اليومية — ضمن المرحلة القادمة من المشروع." />
        <div className="grid cols-2 stagger">
          {mods.map((m) => (
            <Card key={m.t} className="soon-card"><span className="pc-ico" style={{ '--c': 'var(--life)' } as never}><Icon name={m.i} size={24} /></span><h3>{m.t}</h3><p className="muted">{m.d}</p><Badge dashed>قريبًا</Badge></Card>
          ))}
        </div>
        <p className="muted" style={{ marginBlockStart: 'var(--s-5)' }}>لا بيانات صحية أو مالية في هذه المرحلة. عند إضافتها ستُحفظ محليًا فقط.</p>
      </div>
    );
  }
  return (
    <div className="page">
      <PageHead title="المكتبة" icon="library" badge={<Badge dashed>قريبًا</Badge>} sub="معاينة شكل مركز المستندات — يُبنى في المرحلة 2. لا ملفات حقيقية هنا." actions={<Button icon="upload" disabled>ربط مجلد (قريبًا)</Button>} />
      <div className="stack" style={{ gap: 'var(--s-5)' }}>
        <div className="grid cols-3">
          <StatTile tone="blue" icon="file" label="مستندات" value="—" sub="بعد ربط المجلد" />
          <StatTile tone="purple" icon="slides" label="شرائح" value="—" />
          <StatTile tone="pink" icon="video" label="فيديو" value="—" />
        </div>
        <div className="hub" aria-label="معاينة مركز المستندات (بدون بيانات)">
          <aside className="hub-tree">
            <h3>المجلدات</h3>
            {['المواد', 'المحاضرات', 'المختبرات', 'الاختبارات'].map((t, i) => (<div key={t} className="hub-folder" style={{ paddingInlineStart: i ? 20 : 0 }}><Icon name="folder" size={16} /> {t}</div>))}
            <p className="muted" style={{ fontSize: 'var(--fs-xs)' }}>الهيكل المقترح — يُحدَّد عند الربط.</p>
          </aside>
          <div>
            <div className="hub-tabs" role="tablist" aria-label="نوع الملف">
              {TYPES.map((t, i) => (<button key={t.label} role="tab" aria-selected={i === 0} className="chip" disabled><Icon name={t.icon} size={14} /> {t.label}</button>))}
              <span className="spacer" />
              <div className="field-inline"><Icon name="search" size={16} /><input className="input" disabled placeholder="ابحث في المكتبة…" aria-label="بحث في المكتبة (غير مفعّل)" /></div>
            </div>
            <div className="dt" aria-hidden="true">
              <div className="dt-head" style={{ gridTemplateColumns: '44px minmax(200px,2fr) 1fr 90px 120px 1fr' }}>
                <span /><span>الاسم</span><span>المادة</span><span>الحجم</span><span>آخر تعديل</span><span>الوسوم</span>
              </div>
              {[0, 1, 2, 3, 4].map((r) => (
                <div key={r} className="dt-row" style={{ gridTemplateColumns: '44px minmax(200px,2fr) 1fr 90px 120px 1fr' }}>
                  <span><input type="checkbox" disabled tabIndex={-1} /></span>
                  <span className="row" style={{ flexWrap: 'nowrap' }}><span className="file-ico"><Icon name="file" size={16} /></span><Skeleton h={12} w={`${60 + ((r * 13) % 30)}%`} /></span>
                  <span><Skeleton h={12} w="50%" /></span><span><Skeleton h={12} w="60%" /></span><span><Skeleton h={12} w="70%" /></span><span><Skeleton h={22} w="55%" r={11} /></span>
                </div>
              ))}
            </div>
          </div>
        </div>
        <Card>
          <CardHead title="كيف ستعمل المكتبة؟" icon="info" />
          <VSteps steps={[{ title: 'تربط مجلدًا على جهازك', text: 'يقرأ المسح الملفات محليًا ولا يرفع شيئًا.' }, { title: 'تُصنَّف الملفات تلقائيًا', text: 'حسب المادة والنوع واسم الملف، وتراجع أنت النتائج.' }, { title: 'تبحث وتفتح بسرعة', text: 'بحث نصي سريع داخل أسماء الملفات والوسوم.' }]} />
        </Card>
        <EmptyState icon="library" title="لا مكتبة بعد" text="هذه معاينة للتصميم فقط، تُملأ ببياناتك الحقيقية في المرحلة 2." />
      </div>
    </div>
  );
}
