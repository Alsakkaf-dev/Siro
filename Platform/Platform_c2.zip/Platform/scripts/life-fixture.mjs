// مولّد صادرات «راشد» وهمية (FIXTURE) تطابق قاموس البيانات، للاختبارات فقط. كل القيم مصطنعة وتحمل writer: "FIXTURE (synthetic)".
import fs from 'node:fs';
import path from 'node:path';

const KL = (d) => new Date(d.getTime() + 8 * 3600e3).toISOString().slice(0, 19) + '+08:00';

export function buildLifeFixture(dir, opts = {}) {
  const now = opts.now ?? new Date();
  const generatedAt = opts.generatedAt ?? KL(now);
  const w = (rel, data) => {
    const p = path.join(dir, ...rel.split('/'));
    fs.mkdirSync(path.dirname(p), { recursive: true });
    const text = typeof data === 'string' ? data : JSON.stringify(data, null, 2);
    fs.writeFileSync(p, text, 'utf8');
    return Buffer.byteLength(text, 'utf8');
  };
  const day = (n) => new Date(now.getTime() + (8 + 24 * n) * 3600e3).toISOString().slice(0, 10);
  const items = (t, m, d) => [
    { key: 'treasury', label_ar: 'الخزينة', amount: t, currency: 'RM', confidence: 'محسوب' },
    { key: 'monthly', label_ar: 'الشهري', amount: m, currency: 'RM', confidence: 'محسوب' },
    { key: 'daily', label_ar: 'اليومية', amount: d, currency: 'RM', confidence: 'محسوب' },
    { key: 'total', label_ar: 'المجموع', amount: t + m + d, currency: 'RM', confidence: 'محسوب' },
  ];
  const tx = [];
  const cats = ['طعام وبقالة', 'اشتراكات', 'ترفيه وألعاب', 'نقل ووقود', null];
  for (let i = 0; i < 24; i++) {
    tx.push({ id: `FIX-${i}`, order: i + 1, date: day(-(24 - i) / 3 | 0), type: i % 6 === 5 ? 'transfer' : 'expense', type_ar: i % 6 === 5 ? 'تحويل' : 'مصروف', amount: 3 + (i % 7) * 1.5, currency: 'RM', wallet: i % 3 === 0 ? 'يومية' : 'خزينة', label_ar: `بند ${i}`, confidence: 'مثبت', cash_delta: i % 6 === 5 ? 0 : -(3 + (i % 7) * 1.5), category_ar: i % 6 === 5 ? undefined : cats[i % cats.length], category_confidence: 'افتراض' });
  }
  const finance = {
    balances_block: { title: 'الأرصدة اليوم:', as_of: generatedAt, items: items(1000, 50, 20) },
    accounts: [{ key: 'rhb', label_ar: 'RHB', amount: 1050, currency: 'RM', confidence: 'مثبت', stated_at: generatedAt }, { key: 'tng', label_ar: 'TNG', amount: 20, currency: 'RM', confidence: 'مثبت', stated_at: generatedAt }],
    open_items: [{ id: 'F-1', status: 'open', title_ar: 'بند مفتوح وهمي', detail_ar: 'للاختبار فقط', amount: 10, confidence: 'محسوب', applied_to_boxes: false }],
    computed_notes: [{ text_ar: 'ملاحظة محسوبة وهمية', math: '50 - 5×14 = -20', confidence: 'محسوب' }],
    receivables: [{ person_ar: 'فلان', amount: null, last_recorded_amount: 12.5, confidence: 'افتراض', note_ar: 'مبلغ غير مؤكد' }],
    schedule: { title_ar: 'تحويل تلقائي', from_account: 'RHB', to_account: 'TNG', time_ar: '12:00', time_confidence: 'مثبت', periods: [{ from: day(0), to: day(5), per_day: 14, currency: 'RM', status: 'active', confidence: 'مثبت' }, { from: day(6), to: null, per_day: 16, currency: 'RM', status: 'open', confidence: 'افتراض' }] },
    rules_summary: [{ text_ar: 'قاعدة وهمية', confidence: 'مثبت' }],
    verification: { method_ar: 'تحقق وهمي', ledger_based: { treasury: 1000, monthly: 50, daily: 20, total: 1070 }, confidence: 'محسوب' },
    recent_transactions: tx,
    recent_transactions_note_ar: 'آخر حركات وهمية',
  };
  if (opts.balanceHistory === 'items') {
    finance.balance_history = [-6, -3, 0].map((n, i) => ({ as_of: `${day(n)}T12:00:00+08:00`, items: items(900 + i * 50, 80 - i * 15, 30 - i * 5) }));
  } else if (opts.balanceHistory === 'flat') {
    finance.balance_history = [-6, -3, 0].map((n, i) => ({ date: day(n), treasury: 900 + i * 50, monthly: 80 - i * 15, daily: 30 - i * 5, total: 1010 + i * 30 }));
  } else if (opts.balanceHistory === 'one') {
    finance.balance_history = [{ date: day(0), treasury: 1000, monthly: 50, daily: 20, total: 1070 }];
  } else if (opts.balanceHistory === 'garbage') {
    finance.balance_history = [{ foo: 1 }, 'x', { date: 'not-a-date', treasury: 1 }];
  }
  const st = (a) => Object.fromEntries(['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'].map((k, i) => [k, a[i]]));
  const prayers = {
    attendance: {
      title_ar: 'حضور', statuses_ar: { in_time: 'في وقتها', late: 'متأخرة', missed: 'فاتت', unknown: 'غير معروف' },
      days: [
        { date: day(-2), status: st(['missed', 'missed', 'missed', 'missed', 'missed']), counts: { in_time: 0, late: 0, missed: 5, unknown: 0 }, confidence: 'مثبت' },
        { date: day(-1), status: st(['in_time', 'late', 'missed', 'unknown', 'unknown']), counts: { in_time: 1, late: 1, missed: 1, unknown: 2 }, confidence: 'مثبت', note_ar: 'وهمي' },
      ],
      totals: { in_time: 1, late: 1, missed: 6, unknown: 2 }, totals_confidence: 'محسوب', coverage_note_ar: 'السجل وهمي',
    },
    qada: {
      title_ar: 'القضاء', as_of: generatedAt, remaining: { fajr: { count: 10, name_ar: 'الفجر' }, dhuhr: { count: 20, name_ar: 'الظهر' }, asr: { count: 30, name_ar: 'العصر' }, maghrib: { count: 40, name_ar: 'المغرب' }, isha: { count: 50, name_ar: 'العشاء' } },
      total_remaining: 150, done_total: 0, done_today: 0, confidence: 'محسوب', done_confidence: 'مثبت', baseline: { date: day(-2), total: 140, confidence: 'مثبت' },
      history: [{ date: day(-2), fajr: 8, dhuhr: 18, asr: 28, maghrib: 38, isha: 48, total: 140, note_ar: 'أساس' }, { date: day(-1), fajr: 10, dhuhr: 20, asr: 30, maghrib: 40, isha: 50, total: 150 }],
      pending_ar: 'معلّق وهمي', rule_ar: 'قاعدة وهمية',
    },
  };
  const targets = (k) => Array.from({ length: 14 }, (_, i) => ({ date: day(i - 8), plan_day: i + 1, [k]: k === 'reduction_min' ? 20 * (i + 1) : 67 - 3 * i }));
  const counters = { days_logged: 3, days_kept: 1, days_not_kept: 1, days_unknown: 1, current_streak_days: 0, best_streak_days: 1, relapses: [], confidence: 'محسوب' };
  const habits = {
    status: { started: false, started_confidence: 'مثبت', note_ar: 'لم تبدأ (وهمي)' },
    habits: [
      { key: 'vape', name_ar: 'تقليل الفيب', kind: 'taper', unit: 'minutes', priority: 3, rule_ar: 'قاعدة', start_date: day(-8), step_per_day: 20, baseline_daily_minutes: null, targets: targets('reduction_min'), today: { date: day(0), plan_day: 9, reduction_min: 180, confidence: 'محسوب' }, no_vape_windows_ar: 'نافذة وهمية', log: [{ date: day(-1), kept_limit: 'no', confidence: 'مثبت' }, { date: day(-2), kept_limit: 'yes', confidence: 'مثبت' }], counters },
      { key: 'tea_sugar', name_ar: 'سكر الشاي', kind: 'taper', unit: 'grams', rule_ar: 'قاعدة', start_date: day(-8), step_per_day: -3, targets: targets('sugar_limit_g'), today: { date: day(0), plan_day: 9, sugar_limit_g: 43, confidence: 'محسوب' }, zero_from: day(15), log: [], counters },
      { key: 'water', name_ar: 'الماء', kind: 'daily_target', unit: 'liters', target: 3, log: [], counters: { days_logged: 0, days_on_target: 0, current_streak_days: 0, best_streak_days: 0 } },
      { key: 'sleep', name_ar: 'النوم', kind: 'daily_target', target_bedtime: '22:30', log: [], counters: { days_logged: 0 } },
      { key: 'food', name_ar: 'الأكل', kind: 'daily_target', target_kcal: 1500, target_protein_g: 120, log: [], counters: { days_logged: 0 } },
      { key: 'workout', name_ar: 'التمرين', kind: 'schedule', unit: 'sessions', time_slot: { start: '06:15', end: '07:15', confidence: 'افتراض' }, week_plan: ['sat', 'sun', 'mon', 'tue', 'wed', 'thu', 'fri'].map((d, i) => ({ day: d, day_ar: d, type: i % 2 ? 'walk' : 'strength_A', type_ar: i % 2 ? 'مشي' : 'قوة A' })), today: { date: day(0), type_ar: 'مشي', confidence: 'افتراض' }, log: [{ date: day(-1), done: 'no', confidence: 'مثبت' }], counters: { days_logged: 1, days_done: 0, current_streak_days: 0, best_streak_days: 0 } },
    ],
    daily_summary: [{ date: day(-1), vape_kept: 'no', trained: 'no', confidence: 'مثبت' }],
  };
  const blk = (name, start, end, days, kind, extra = {}) => ({ name, start, end, days, days_ar: days, calendar: 'روتين وصحة', kind, moves_with_prayer_time: false, source_id: 'FIX', confidence: 'مثبت', ...extra });
  const all7 = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  const routine = {
    timezone: 'Asia/Kuala_Lumpur', as_of_note_ar: 'وهمي',
    prayer_times_reference: { date: day(-12), zone: 'JHR02', fajr: '05:32', dhuhr: '12:56', asr: '16:09', maghrib: '18:55', isha: '20:05', confidence: 'مثبت' },
    daily_blocks: [blk('نوم', '00:00', '05:00', all7, 'sleep'), blk('الظهر', '12:56', '13:16', all7, 'prayer', { moves_with_prayer_time: true, calendar: 'صلاة' }), blk('تمرين', '06:15', '07:15', all7, 'routine')],
    weekly_study_blocks: [blk('ProfComm', '08:00', '10:00', ['mon'], 'lecture', { calendar: 'دراسة' })],
    local_routines: [{ name: 'سؤال المصروف', time: '21:45', flex_min: 15, days: all7, days_ar: all7, calendar: null, in_outlook: false, confidence: 'مثبت' }],
    known_conflicts: [{ id: 'RC-1', text_ar: 'تعارض وهمي' }],
    holidays: [{ name_ar: 'عطلة وهمية', from: day(13), to: day(14), confidence: 'مثبت' }],
  };
  const body = {
    date: day(-5),
    items: [{ key: 'height', label_ar: 'الطول', value: 170, unit: 'cm', confidence: 'مثبت' }, { key: 'weight', label_ar: 'الوزن', value: 80, unit: 'kg', confidence: 'مثبت', date: day(-5) }, { key: 'body_fat', label_ar: 'الدهون', value: 30, unit: '%', approx: true, confidence: 'مثبت' }, { key: 'goal_weight', label_ar: 'الهدف', value: 70, unit: 'kg', confidence: 'مثبت' }],
    goal_kg: 70, latest_recorded_weight: { date: day(-1), value_kg: 79, confidence: 'مثبت' },
    weight_history_note_ar: 'تعارض وهمي',
    weight_history: [{ date: day(-12), value_kg: 81, confidence: 'افتراض', status_ar: 'مبدئي' }, { date: day(-5), value_kg: 80, confidence: 'مثبت', status_ar: 'خط الأساس' }, { date: day(-1), value_kg: 79, confidence: 'مثبت', status_ar: 'آخر قراءة' }],
  };
  const summary = {
    generated_at: generatedAt, read_only: true, balances_block: finance.balances_block, balances_source: 'وهمي',
    qada: { ...prayers.qada, source: 'وهمي' },
    habits: { title_ar: 'عدادات', started: false, started_confidence: 'مثبت', note_ar: 'لم تبدأ', items: habits.habits.slice(0, 2).map((h) => ({ key: h.key, name_ar: h.name_ar, today_plan_day: 9, today_target_ar: 'هدف', today_target: 180, unit: h.unit, current_streak_days: 0, days_kept: 1, days_not_kept: 1, confidence: 'محسوب' })) },
    open_finance_items: { title_ar: 'بنود مفتوحة', items: finance.open_items },
    open_loops_count: { title_ar: 'بنود', open_or_waiting: 3, open: 2, waiting: 1, partially_closed: 0, closed: 4, total_rows: 7, confidence: 'محسوب' },
  };
  const data = { finance, prayers, habits, routine, body, dashboard_summary: summary };
  const files = [];
  for (const [name, d] of Object.entries(data)) {
    const bytes = w(`${name}.json`, d);
    const hours = { finance: 24, prayers: 12, habits: 24, routine: 168, body: 168, dashboard_summary: 24 }[name];
    files.push({ name: `${name}.json`, type: 'json', description_ar: 'وهمي', bytes, generated_at: opts.fileGeneratedAt?.[name] ?? generatedAt, stale_after_hours: hours, stale_after_confidence: 'افتراض' });
  }
  if (opts.badBytes) files.find((f) => f.name === opts.badBytes + '.json').bytes += 7;
  w('docs/SPORTS_CONTENT_AR.md', '# وهمي\n');
  w('commands/README_AR.md', 'وهمي');
  w('commands/examples/log_expense.example.json', { id: 'EXAMPLE-LOG_EXPENSE', status: 'example', type: 'log_expense', created_at: generatedAt, payload: {} });
  if (!opts.noMeta) w('exports_meta.json', { version: 3, generated_at: generatedAt, timezone: 'Asia/Kuala_Lumpur', writer: 'FIXTURE (synthetic)', read_only: true, files });
  return dir;
}
