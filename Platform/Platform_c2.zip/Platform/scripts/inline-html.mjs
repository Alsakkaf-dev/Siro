// بعد بناء Vite: يُدرج في index.html سكربتًا صغيرًا مضمَّنًا (بدون طلب شبكة يحجب العرض) يقوم بـ:
//  1) ضبط المظهر (فاتح/داكن) قبل أول رسم؛
//  2) بدء جلب بيانات الـ API وتنزيل حزمة الصفحة الحالية بالتوازي مع الحزمة الرئيسية.
// الخادم يحسب بصمة sha256 للسكربت المضمَّن عند التشغيل ويضيفها إلى CSP.
import { readFileSync, writeFileSync, rmSync, readdirSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const web = resolve(dirname(fileURLToPath(import.meta.url)), '..', 'dist', 'web');
const htmlFile = join(web, 'index.html');
let html = readFileSync(htmlFile, 'utf8');
const tag = '<script src="/theme-init.js"></script>';
if (!html.includes(tag)) {
  console.log('inline-html: theme-init tag not found (already inlined?)');
  process.exit(0);
}
const theme = readFileSync(join(web, 'theme-init.js'), 'utf8').trim();
const assets = readdirSync(join(web, 'assets')).filter((f) => f.endsWith('.js'));
const file = (name) => assets.find((f) => new RegExp('^' + name + '-[A-Za-z0-9_-]+\\.js$').test(f));
// المسار (بعد /academic/s/:id) -> الحزم
const routes = {
  home: ['Home'],
  semesters: ['Semesters'],
  courses: ['Courses', 'catalog'],
  course: ['CoursePage', 'catalog'],
  timeline: ['Timeline'],
  calculator: ['Calculator'],
  weights: ['Weights'],
  unknowns: ['Unknowns'],
  print: ['PrintSummary'],
  settings: ['Settings'],
  life: ['Life', 'lifeKit'],
  lifeFinance: ['LifeFinance', 'lifeKit'],
  lifePrayers: ['LifePrayers', 'lifeKit'],
  lifeHabits: ['LifeHabits', 'lifeKit'],
  lifeRoutine: ['LifeRoutine', 'lifeKit'],
  lifeBody: ['LifeBody', 'lifeKit'],
  lifeCommands: ['LifeCommands', 'lifeKit'],
  lifeSettings: ['LifeSettings', 'lifeKit'],
  search: ['SearchPage'],
};
const cssAssets = readdirSync(join(web, 'assets')).filter((f) => f.endsWith('.css'));
const lifeCss = cssAssets.find((f) => /^lifeKit-[A-Za-z0-9_-]+\.css$/.test(f));
const map = {};
for (const [k, names] of Object.entries(routes)) map[k] = names.map(file).filter(Boolean).map((f) => '/assets/' + f);
const boot = `;(function(){try{
var p=location.pathname,m=p.match(/^\\/academic\\/s\\/([^\\/]+)(?:\\/([^\\/]+))?(?:\\/([^\\/]+))?\$/),pre=window.__pre={};
function g(u){pre[u]=fetch(u).then(function(r){return r.text().then(function(t){return{ok:r.ok,status:r.status,text:t}})});pre[u].catch(function(){})}
g('/api/semesters');if(m)g('/api/semesters/'+m[1]);
var R=${JSON.stringify(map)},C=${JSON.stringify(lifeCss ? '/assets/' + lifeCss : '')},k=null;
if(m){k=!m[2]?null:m[2]==='courses'?(m[3]?'course':'courses'):R[m[2]]?m[2]:null}
else if(p==='/')k='home';else if(p==='/academic')k='semesters';else if(p==='/settings')k='settings';else if(p.indexOf('/life')===0){var L={'/life':['Life','dashboard_summary,finance,prayers,habits,body,routine'],'/life/finance':['LifeFinance','finance'],'/life/prayers':['LifePrayers','prayers'],'/life/habits':['LifeHabits','habits'],'/life/routine':['LifeRoutine','routine'],'/life/body':['LifeBody','body'],'/life/commands':['LifeCommands','finance'],'/life/settings':['LifeSettings','finance']}[p.replace(/\\/\$/,'')];if(L){k='life'+L[0].slice(4);if(k==='life')k='life';g('/api/life/bundle?files='+encodeURIComponent(L[1]))}}else if(p==='/search')k='search';
if(k&&k.indexOf('life')===0&&C){var c=document.createElement('link');c.rel='preload';c.as='style';c.crossOrigin='';c.href=C;document.head.appendChild(c)}
if(k&&R[k])R[k].forEach(function(h){var l=document.createElement('link');l.rel='modulepreload';l.href=h;document.head.appendChild(l)});
}catch(e){}})();`.replace(/\n/g, '');
const js = theme + boot;
html = html.replace(tag, () => `<script>${js}</script>`);
writeFileSync(htmlFile, html);
rmSync(join(web, 'theme-init.js'));
console.log('inline-html: boot script inlined (' + js.length + ' bytes), routes:', JSON.stringify(map).length, 'bytes');
