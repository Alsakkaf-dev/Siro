
### Cycle 4 — CP2 (v6 sports safety) ✅
- Types for Rashed v6 (beginner_safe / safety_note_ar / safer_alternative_id, safety_review, plans disclaimer/changelog, session safety pairs).
- UI: «ليس للمبتدئ»/«للمبتدئ» badges, "مناسب للمبتدئ فقط" filter, disclaimer banner (injuries shown as «غير مسجلة», never "none"), detail safety block with clickable safer alternative, session safety notes, v2 changelog card, «تماريني» warning + one-click swap to the safer alternative.
- Tests: real-data v6 consistency test (29 unsafe, ids resolve, pairs align); e2e_sports v6 step green at 1280/390. vitest 117, smoke 39.

### Cycle 4 — CP3 (weekly review model) ✅
- shared/weekly.ts: pure model for «مراجعة الأسبوع» per docs/WEEKLY_REVIEW_SPEC_AR.md (window Sun–Sat KL [افتراض], missing ≠ 0, weakest-tag rule, «ما ينقص» list). 21 tests incl. real-data invariants (conditional). UI next.

### Cycle 4 — CP4 (مراجعة الأسبوع per spec) ✅
- `/review` rebuilt from docs/WEEKLY_REVIEW_SPEC_AR.md: Sun–Sat KL window [افتراض] + «يوم السبت ما انتهى» + last-week toggle; sections in spec order (prayer → habits → weight → money → routine/next week → «ما ينقص»); every number has a confidence tag (glossary popover); missing = «غير مسجل» (never 0); review-day note (Sat 09:00 [افتراض] vs Sun, unresolved); per-file generated_at + «قديم» badge. Read-only; no commands sent.
- Old Saturday-first helpers removed from shared/review.ts. Tests: vitest 135 (both DB drivers), e2e_c4 ALL PASSED at 1280/390.

### Cycle 4 — CP5 (chunk 1 closed) ✅
- v6 safety UI verified end-to-end (badges, note, safer-alternative link, disclaimer, injuries «غير مسجلة», session notes, changelog, swap in «تماريني»); e2e_sports ALL GREEN 1280/390.
- /review audited line-by-line against WEEKLY_REVIEW_SPEC_AR.md; added relapses line + time on as_of. Removed content-visibility (broke innerText/copy). e2e_c4 ALL PASSED. vitest 135 (both drivers), smoke 39.
- Boot prefetch added for /sports*, /review (content + bundle); life chunk preloads. Mobile Lighthouse: 20 pages 93–100 (noise ±3; life/glossary occasionally 93–94 → chunk 2).
- README_AR + DESIGN_REFERENCES updated (safety, review, palette, bell, appearance, glossary, offline).
- Pending from parent: v7/v8 files (ledger_full.json, ROUTINE_BLOCKS_AR.json, FINANCE_INSIGHTS_AR.json, PRAYER_QADA_PLAN_AR.json).
