// اختبار دخان: يشغّل الخادم على منفذ مؤقت وبيانات مؤقتة ويتحقق من أهم المسارات. الاستخدام: npm run smoke
import { spawn } from 'node:child_process';
import http from 'node:http';
import { mkdtempSync, readdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const port = 4300 + Math.floor(Math.random() * 90);
const tmp = mkdtempSync(join(tmpdir(), 'platform-smoke-'));
const { buildLibraryFixture } = await import(pathToFileURL(join(root, 'scripts', 'lib-fixture.mjs')).href);
const libRoot = await buildLibraryFixture(join(tmp, 'library'));
const env = { ...process.env, PLATFORM_PORT: String(port), PLATFORM_DATA_DIR: join(tmp, 'data'), PLATFORM_BACKUPS_DIR: join(tmp, 'backups'), PLATFORM_LIBRARY_ROOT: libRoot, PLATFORM_NO_AUTOSCAN: '1' };
const child = spawn(process.execPath, ['server'], { cwd: root, env, stdio: ['ignore', 'pipe', 'pipe'] });
let log = '';
child.stdout.on('data', (d) => (log += d));
child.stderr.on('data', (d) => (log += d));

const base = `http://127.0.0.1:${port}`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let pass = 0;
let fail = 0;
const ok = (name, cond, extra = '') => {
  if (cond) pass++;
  else fail++;
  console.log(`${cond ? '  ✓' : '  ✗'} ${name}${cond ? '' : '  ' + extra}`);
};
const get = async (p, opt = {}) => {
  const r = await fetch(base + p, opt);
  const t = await r.text();
  let j = null;
  try { j = JSON.parse(t); } catch { /* ليس JSON */ }
  return { r, t, j };
};

try {
  for (let i = 0; i < 60; i++) {
    try { if ((await fetch(base + '/api/health')).ok) break; } catch { /* لم يبدأ بعد */ }
    await sleep(250);
  }
  console.log(`smoke → ${base}`);
  const h = await get('/api/health');
  ok('GET /api/health', h.j?.ok === true, h.t);
  ok('sqlite driver', ['better-sqlite3', 'node:sqlite'].includes(h.j?.driver), String(h.j?.driver));
  const s = await get('/api/semesters');
  ok('seeded SEM 5 (6 courses, 52 assessments)', s.j?.[0]?.code === 'SEM 5' && s.j[0].course_count === 6 && s.j[0].assessment_count === 52, JSON.stringify(s.j?.[0]));
  const b = await get('/api/semesters/sem5');
  const sums = b.j.courses.map((c) => b.j.assessments.filter((a) => a.course_id === c.id).reduce((x, a) => x + a.weight, 0));
  ok('each course weights = 100 (French has none)', sums.filter((x) => x === 100).length === 5 && sums.filter((x) => x === 0).length === 1, sums.join(','));
  ok('search «كويز»', (await get('/api/search?q=' + encodeURIComponent('كويز'))).j.length > 3);
  ok('search «SCSE3203»', (await get('/api/search?q=SCSE3203')).j.length > 5);
  ok('export has semesters/courses/assessments', (await get('/api/export')).j?.assessments?.length === 47);
  const idx = await get('/');
  ok('GET / serves the app', idx.t.includes('<div id="root">') && idx.r.headers.get('content-security-policy'), 'dist/web missing? run: npm run build');
  const spa = await get('/academic/s/sem5/courses');
  ok('SPA fallback', spa.r.status === 200 && spa.t.includes('<div id="root">'));
  const js = /\/assets\/index-[^"]+\.js/.exec(idx.t)?.[0];
  const asset = await get(js, { headers: { 'Accept-Encoding': 'br' } });
  ok('hashed asset: immutable cache', /immutable/.test(asset.r.headers.get('cache-control') ?? ''));
  ok('hashed asset: brotli', asset.r.headers.get('content-encoding') === 'br');
  const bad = await new Promise((res) => {
    const req = http.request({ host: '127.0.0.1', port, path: '/api/health', headers: { Host: 'evil.example' } }, (r) => { r.resume(); res(r.statusCode); });
    req.on('error', () => res(0));
    req.end();
  });
  ok('foreign Host header → 403', bad === 403, String(bad));
  const v = await get('/api/semesters', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: '' }) });
  ok('validation error → 400 with fields', v.r.status === 400 && v.j?.fields?.code, v.t);

  // ── المكتبة ──
  const st0 = await get('/api/library/status');
  ok('library status: root exists', st0.j?.root_exists === true && st0.j.root === libRoot, st0.t);
  const sc = await get('/api/library/scan?wait=1', { method: 'POST' });
  ok('library scan: 10 files (hidden/node_modules/temp skipped)', sc.j?.result?.scanned === 10 && sc.j.result.added === 10, sc.t);
  const li = await get('/api/library/items?limit=50');
  ok('library items + facets', li.j?.total === 10 && li.j.facets.sem.some((f) => f.value === 'SEM 5'), li.t.slice(0, 200));
  const pdf = li.j.items.find((i) => i.title === 'Lecture 1 Intro.pdf');
  const rawPdf = await get(`/api/library/files/${pdf.id}/raw`);
  ok('raw pdf: application/pdf + sandbox CSP', rawPdf.r.headers.get('content-type') === 'application/pdf' && /sandbox/.test(rawPdf.r.headers.get('content-security-policy') ?? ''), String(rawPdf.r.headers.get('content-type')));
  const mp4 = li.j.items.find((i) => i.title === 'clip.mp4');
  const rng = await fetch(`${base}/api/library/files/${mp4.id}/raw`, { headers: { Range: 'bytes=0-99' } });
  ok('raw video: Range → 206', rng.status === 206 && (await rng.arrayBuffer()).byteLength === 100, String(rng.status));
  const trav = await get('/api/library/files/..%2F..%2Fetc%2Fpasswd/raw');
  ok('raw: bad id → 404', trav.r.status === 404, String(trav.r.status));
  const worker = readdirSync(join(root, 'dist', 'web', 'assets')).find((f) => /^pdf\.worker\.min-.*\.mjs$/.test(f));
  const workerUrl = worker ? '/assets/' + worker : null;
  ok('pdf worker bundled as asset', !!worker);
  if (workerUrl) {
    const w = await fetch(base + workerUrl);
    ok('pdf worker served as javascript', /javascript/.test(w.headers.get('content-type') ?? '') && w.status === 200, w.headers.get('content-type') ?? '');
  }
  const fonts = await fetch(base + '/pdfjs/standard_fonts/FoxitSerif.pfb');
  ok('pdfjs standard fonts served locally', fonts.status === 200, String(fonts.status));
  const ytAdd = await get('/api/library/youtube', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url: 'https://youtu.be/dQw4w9WgXcQ', title: 'smoke' }) });
  ok('youtube add', ytAdd.r.status === 201 && ytAdd.j?.video_id === 'dQw4w9WgXcQ', ytAdd.t);
  const ytBad = await get('/api/library/youtube', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url: 'https://evil.example/watch?v=dQw4w9WgXcQ' }) });
  ok('youtube: non-YouTube url rejected', ytBad.r.status === 400 || ytBad.r.status === 422, String(ytBad.r.status));
  const ytDel = await get(`/api/library/youtube/${ytAdd.j.id}`, { method: 'DELETE' });
  ok('youtube delete (record only)', ytDel.j?.ok === true, ytDel.t);
  ok('files untouched by scan', (await get('/api/library/items?limit=50')).j.total === 10);
} catch (e) {
  fail++;
  console.log('  ✗ exception', e);
} finally {
  child.kill();
  await sleep(300);
  rmSync(tmp, { recursive: true, force: true });
}
console.log(`\n${fail ? 'FAILED' : 'OK'} — ${pass} passed, ${fail} failed`);
if (fail) console.log(log);
process.exit(fail ? 1 : 0);
