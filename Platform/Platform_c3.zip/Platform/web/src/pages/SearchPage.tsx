import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { api } from '../lib/api.js';
import { PageHead } from '../ui/page.js';
import { Badge, Card, EmptyState, Skeleton } from '../ui/ui.js';
import type { SearchHit } from '../../../shared/types.js';

export default function SearchPage() {
  const [sp] = useSearchParams();
  const q = sp.get('q')?.trim() ?? '';
  const [hits, setHits] = useState<SearchHit[] | null>(null);
  useEffect(() => {
    setHits(null);
    if (!q) {
      setHits([]);
      return;
    }
    let live = true;
    api.search(q).then((h) => live && setHits(h)).catch(() => live && setHits([]));
    return () => {
      live = false;
    };
  }, [q]);
  return (
    <div className="page">
      <PageHead title={q ? <>نتائج «{q}»</> : 'البحث'} icon="search" sub="ابحث عن مادة أو تقييم أو محاضر أو نوع (كويز، لاب، ميدتيرم…)." />
      {hits === null ? <Skeleton h={200} r={20} /> : hits.length === 0 ? <EmptyState icon="search" title={q ? 'لا نتائج' : 'اكتب ما تبحث عنه في شريط البحث'} text={q ? 'جرّب كلمة أقصر أو رمز المادة.' : undefined} /> : (
        <Card>
          <ul className="plain">
            {hits.map((h) => (
              <li key={`${h.type}${h.id}`}>
                <Link to={`/academic/s/${h.semester_id}/courses/${h.course_id}${h.type === 'assessment' ? `#a-${h.id}` : ''}`} className="hit">
                  <i className="dot" style={{ background: h.color }} />
                  <span><bdi>{h.title}</bdi><small><bdi>{h.subtitle}</bdi></small></span>
                  <span style={{ marginInlineStart: 'auto' }}><Badge>{h.type === 'course' ? 'مادة' : 'تقييم'}</Badge> <Badge dashed><bdi>{h.semester_code}</bdi></Badge></span>
                </Link>
              </li>
            ))}
          </ul>
        </Card>
      )}
    </div>
  );
}
