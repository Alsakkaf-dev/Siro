import { useMemo, useState } from 'react';
import { useApp } from '../core/app-context.js';
import { ApiError, sports } from '../lib/api.js';
import { PageHead } from '../ui/page.js';
import { Badge, Button, Card, CardHead, EmptyState, Skeleton } from '../ui/ui.js';
import { useNow } from '../widgets/tiles.js';
import { BodyMap, ConfBadge, ContentBanner, sessionRegions, useExercises, useMine, usePlans } from '../sports/sportsKit.js';
import { describeSE, fmtRange, KIND_AR, LOCATION_AR, WEEKDAY_AR, weekdayKL, type Exercise, type Session, type Template } from '../../../shared/sports.js';

const KIND_COLOR: Record<string, string> = { strength: 'var(--sports)', cardio: '#4CC9F0', mobility: '#A78BFA', rest: '#8A92B2' };

function durationText(s: Session): string {
  const d = s.duration_minutes as { min?: number; max?: number; weeks_1_4?: { min: number; max: number }; weeks_5_plus?: { min: number; max: number } } | undefined;
  if (!d) return '';
  if (d.weeks_1_4 || d.weeks_5_plus) return [d.weeks_1_4 && `أسابيع 1–4: ${fmtRange(d.weeks_1_4)} د`, d.weeks_5_plus && `من الأسبوع 5: ${fmtRange(d.weeks_5_plus)} د`].filter(Boolean).join(' · ');
  if (typeof d.min === 'number' && typeof d.max === 'number') return `${fmtRange(d as { min: number; max: number })} دقيقة`;
  return '';
}

export default function SportsTemplates() {
  const plans = usePlans();
  const ex = useExercises();
  const { mine, set, loaded } = useMine();
  const { toast } = useApp();
  const now = useNow(60_000);
  const [loc, setLoc] = useState<'all' | 'home' | 'gym'>('all');
  const [pickId, setPickId] = useState<string | null>(null);
  const [sess, setSess] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const p = plans.data;
  const byEx = useMemo(() => new Map<string, Exercise>((ex.data?.exercises ?? []).map((e) => [e.id, e])), [ex.data]);
  const bySess = useMemo(() => new Map<string, Session>((p?.sessions ?? []).map((s) => [s.id, s])), [p]);
  const list = useMemo(() => (p?.templates ?? []).filter((t) => loc === 'all' || t.location === loc), [p, loc]);
  const cur: Template | undefined = list.find((t) => t.id === pickId) ?? list.find((t) => t.id === mine.template) ?? list[0];
  const today = weekdayKL(now);
  const head = <PageHead title="القوالب الأسبوعية" icon="calendar" sub="ستة قوالب مقترحة من راشد — كلها افتراض حتى تختار أنت." crumbs={[{ to: '/sports', label: 'الرياضة' }, { label: 'القوالب' }]} actions={<Button to="/sports/mine" variant="primary" icon="plus">تمريني</Button>} />;

  if (plans.loading) return <div className="page sports-page">{head}<Skeleton h={90} r={16} /><div style={{ height: 12 }} /><Skeleton h={320} r={16} /></div>;
  if (plans.error) return <div className="page sports-page">{head}<EmptyState icon="warn" title="تعذّر الاتصال بالخادم" text={plans.error} action={<Button onClick={plans.reload}>إعادة المحاولة</Button>} /></div>;
  if (!plans.rootExists || !p) {
    return (
      <div className="page sports-page">
        {head}
        <ContentBanner status={plans.status} label="قوالب التمرين" />
        <EmptyState icon="calendar" title="قوالب التمرين غير متاحة" text={!plans.rootExists ? 'مجلد صادرات راشد غير موجود.' : 'ملف docs/SPORTS_PLANS_AR.json غير متاح أو تغيّر تنسيقه.'} action={<Button to="/life/settings" icon="sliders">إعدادات الحياة</Button>} />
      </div>
    );
  }
  const shown = sess ? bySess.get(sess) : undefined;
  const rawSel = p.selected_template_id ?? null;

  const choose = async (t: Template): Promise<void> => {
    setBusy(true);
    try {
      const loc2 = t.location === 'home' || t.location === 'gym' ? t.location : undefined;
      set(await sports.settings({ template: t.id, ...(loc2 ? { location: loc2 } : {}) }));
      toast(`اعتمدتَ «${t.name_ar}» في موقعك`, { kind: 'ok' });
    } catch (e) {
      toast(e instanceof ApiError ? e.message : (e as Error).message, { kind: 'error' });
    } finally {
      setBusy(false);
    }
  };
  const copy = async (s: Session): Promise<void> => {
    setBusy(true);
    try {
      const items = (s.exercises ?? []).map((se) => {
        const e = byEx.get(se.exercise_id);
        return { exercise_id: se.exercise_id, en_name: e?.english_name ?? se.exercise_id, ar_name: e?.arabic_name ?? se.exercise_id, sets: se.sets?.min ?? null, reps_min: se.reps?.min ?? null, reps_max: se.reps?.max ?? null, duration_s: se.duration_seconds?.min ?? null, per_side: !!se.per_side };
      });
      await sports.create({ name: s.name_ar.slice(0, 80), note: 'نُسخ من قالب راشد (افتراض). عدّل ما شئت.', items });
      set(await sports.mine());
      toast('نُسخت الجلسة إلى «تمريني»', { kind: 'ok' });
    } catch (e) {
      toast(e instanceof ApiError ? Object.values(e.fields)[0] ?? e.message : (e as Error).message, { kind: 'error' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="page sports-page">
      {head}
      <ContentBanner status={plans.status} label="قوالب التمرين" />
      <p className="life-note warn"><span>{p.note_ar ?? 'كل محتوى القوالب افتراض.'} {p.selection_note_ar}</span></p>
      <div className="row" style={{ gap: 'var(--s-3)', flexWrap: 'wrap' }}>
        <div className="seg" role="group" aria-label="المكان">
          {(['all', 'home', 'gym'] as const).map((k) => (
            <button key={k} type="button" aria-pressed={loc === k} onClick={() => setLoc(k)}>{k === 'all' ? 'الكل' : LOCATION_AR[k]}</button>
          ))}
        </div>
        <span className="muted" style={{ fontSize: 'var(--fs-sm)' }}>
          اختيار راشد المسجّل: {rawSel ? <b>{rawSel}</b> : <b>لم يُسجَّل بعد</b>}
          {loaded && mine.template && <> · اختيارك المحلي: <b>{p.templates.find((t) => t.id === mine.template)?.name_ar ?? mine.template}</b></>}
        </span>
      </div>
      <ul className="tpl-cards" aria-label="القوالب">
        {list.map((t) => (
          <li key={t.id}>
            <button type="button" className="tpl-card" aria-pressed={cur?.id === t.id} onClick={() => { setPickId(t.id); setSess(null); }}>
              <b>{t.name_ar}</b>
              <span className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
                <Badge>{t.days_per_week} أيام</Badge>
                <Badge dashed>{LOCATION_AR[t.location] ?? t.location}</Badge>
                {mine.template === t.id && <Badge tone="ok">اعتمدتُه</Badge>}
              </span>
            </button>
          </li>
        ))}
      </ul>
      {!list.length && <EmptyState icon="calendar" title="لا قوالب لهذا المكان" text="جرّب «الكل»." />}
      {cur && (
        <Card>
          <CardHead title={cur.name_ar} icon="calendar">
            <ConfBadge c={cur.confidence ?? p.confidence} />
            <Button size="sm" variant={mine.template === cur.id ? 'ghost' : 'primary'} icon="check" disabled={busy || mine.template === cur.id} onClick={() => void choose(cur)}>{mine.template === cur.id ? 'معتمد عندك' : 'اعتمد هذا القالب محليًا'}</Button>
          </CardHead>
          <p className="muted" style={{ marginBlockStart: 0 }}>الاعتماد هنا محلي في موقعك فقط؛ لا يغيّر ملفات راشد. إن أردت أن يسجّله راشد قله في المحادثة{cur.recommended_from_week ? ` — يوصى به من الأسبوع ${cur.recommended_from_week}` : ''}.</p>
          <ul className="week-grid" aria-label={`أيام ${cur.name_ar}`}>
            {(p.weekday_order ?? cur.days.map((d) => d.weekday)).map((wd) => {
              const d = cur.days.find((x) => x.weekday === wd);
              const label = d?.weekday_ar ?? WEEKDAY_AR[wd as keyof typeof WEEKDAY_AR] ?? wd;
              return (
                <li key={wd} className={`wk-day ${wd === today ? 'today' : ''}`}>
                  <h3>{label}{wd === today && <Badge tone="accent">اليوم</Badge>}</h3>
                  {d?.sessions.length ? d.sessions.map((sid) => {
                    const s = bySess.get(sid);
                    return (
                      <button key={sid} type="button" className="sess-btn" style={{ '--c': KIND_COLOR[s?.kind ?? ''] ?? 'var(--sports)' } as React.CSSProperties} aria-pressed={sess === sid} onClick={() => setSess(sess === sid ? null : sid)}>
                        {s?.name_ar ?? sid}
                      </button>
                    );
                  }) : <span className="muted">—</span>}
                </li>
              );
            })}
          </ul>
        </Card>
      )}
      {shown && (
        <Card>
          <CardHead title={shown.name_ar} icon="dumbbell">
            <Badge>{KIND_AR[shown.kind] ?? shown.kind}</Badge>
            {shown.exercises?.length ? <Button size="sm" icon="plus" disabled={busy} onClick={() => void copy(shown)}>انسخ إلى تمريني</Button> : null}
          </CardHead>
          <div className="row" style={{ gap: 'var(--s-4)', alignItems: 'flex-start', flexWrap: 'wrap' }}>
            {(shown.exercises?.length ?? 0) > 0 && <BodyMap active={sessionRegions(shown, byEx)} className="sm" />}
            <div style={{ flex: 1, minWidth: 220 }}>
              {durationText(shown) && <p style={{ marginBlockStart: 0 }}>المدة: <b className="num">{durationText(shown)}</b></p>}
              {shown.note_ar && <p className="muted" style={{ marginBlockStart: 0 }}>{shown.note_ar}</p>}
              {shown.exercises?.length ? (
                <ol className="sess-list">
                  {shown.exercises.map((se, i) => {
                    const e = byEx.get(se.exercise_id);
                    return (
                      <li key={`${se.exercise_id}-${i}`}>
                        <span><b>{e?.arabic_name ?? se.exercise_id}</b>{e && <small className="muted" lang="en" dir="ltr" style={{ display: 'block', textAlign: 'start' }}>{e.english_name}</small>}{!e && <small className="muted" style={{ display: 'block' }}>غير موجود في مكتبة التمارين الحالية</small>}</span>
                        <span className="t num">{describeSE(se)}</span>
                      </li>
                    );
                  })}
                </ol>
              ) : <p className="muted" style={{ margin: 0 }}>{shown.kind === 'rest' ? 'يوم راحة.' : 'لا تمارين محددة.'}</p>}
            </div>
          </div>
        </Card>
      )}
      <div className="grid cols-2 cols-1-1">
        {p.phases?.length ? (
          <Card>
            <CardHead title="مراحل التدرّج" icon="timer" />
            <ul className="life-list">
              {p.phases.map((ph) => (
                <li key={ph.id}>
                  <b>{ph.name_ar}</b> <ConfBadge c={ph.confidence} />
                  <small className="muted" style={{ display: 'block' }}>
                    {ph.sets && <>مجموعات {fmtRange(ph.sets)} · </>}{ph.reps && <>تكرارات {fmtRange(ph.reps)} · </>}{ph.rest_seconds && <>راحة {fmtRange(ph.rest_seconds)} ث</>}{ph.lowering_seconds ? <> · نزول {ph.lowering_seconds} ث</> : null}
                  </small>
                </li>
              ))}
            </ul>
          </Card>
        ) : null}
        {p.general_rules?.length ? (
          <Card>
            <CardHead title="قواعد عامة" icon="info" />
            <ul className="rules">
              {p.general_rules.map((r) => <li key={r.id}>{r.text_ar}</li>)}
            </ul>
          </Card>
        ) : null}
      </div>
      {p.goal && (
        <Card>
          <CardHead title="الهدف" icon="flag"><ConfBadge c={p.goal.confidence} /></CardHead>
          <p style={{ margin: 0 }}>
            {typeof p.goal.current_weight_kg === 'number' && <>الوزن المسجّل <b className="num">{p.goal.current_weight_kg} كغ</b></>}
            {typeof p.goal.goal_weight_kg === 'number' && <> → الهدف <b className="num">{p.goal.goal_weight_kg} كغ</b></>}
          </p>
          {p.goal.note_ar && <p className="muted" style={{ marginBottom: 0 }}>{p.goal.note_ar}</p>}
        </Card>
      )}
    </div>
  );
}
