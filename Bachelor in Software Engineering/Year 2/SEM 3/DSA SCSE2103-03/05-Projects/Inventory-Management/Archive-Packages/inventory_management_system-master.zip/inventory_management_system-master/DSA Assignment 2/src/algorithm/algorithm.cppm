export module algorithm;

import model.Item;
import data_structures.List;
import data_structures.Queue;

export List<Item> sort(const List<Item>& items, const PriorityType& sortType)
{
    List<Item> sortedItems;
    PriorityQueue priorityQueue(sortType);
    for (const auto& item : items) { priorityQueue.push(item); }
    for (const auto& elem : priorityQueue) { sortedItems.add(elem); }
    return sortedItems;
}
