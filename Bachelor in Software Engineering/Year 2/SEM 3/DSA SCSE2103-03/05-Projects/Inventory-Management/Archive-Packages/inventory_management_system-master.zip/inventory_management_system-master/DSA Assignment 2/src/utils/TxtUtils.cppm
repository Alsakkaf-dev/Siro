module;
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

export module utils.TxtUtils;

import model.Item;
import data_structures.List;

const std::string FILENAME = "Inventory.txt";

export List<Item> deserializeItemsToList()
{
    List<Item> items{};
    std::fstream file(FILENAME);
    if (!file.is_open())
    {
        std::cerr << "Unable to open file: " << FILENAME << std::endl;
        return items;
    }
    std::string line;
    for (int i = 0; std::getline(file, line); i++)
    {
        std::stringstream ss(line);
        std::string name, qty, unitCost;

        // Split by comma
        std::getline(ss, name, ',');
        std::getline(ss, qty, ',');
        std::getline(ss, unitCost, ',');

        items.add(Item(name, std::stod(unitCost), std::stoi(qty)));
    }
    return items;
}

export bool serializeItemsToTxtFile(const List<Item>& items)
{
    std::ofstream file(FILENAME);
    if (!file.is_open())
    {
        std::cerr << "Unable to save to file: " << FILENAME << "\n";
        return false;
    }

    for (const auto& stock : items)
    {
        file << stock.getItemName() << ','
            << stock.getQuantity() << ','
            << stock.getUnitPrice() << "\n";
    }
    file.close();
    return true;
}
